-- ══════════════════════════════════════════════════════════════
-- 🚀 main.lua — Loader principal
-- Este é o ÚNICO arquivo que o usuário executa.
-- Carrega todos os módulos do GitHub na ordem correta de dependência.
-- ══════════════════════════════════════════════════════════════

-- URL base do seu repositório (raw.githubusercontent.com)
local REPO = "https://raw.githubusercontent.com/DudxJs/ExploitUniverseStudio/main/modules/"

local modules = {
    "config.lua",        -- 1. Constantes, ICONS, variáveis de estado
    "core.lua",          -- 2. makeIcon, makeSwitch, makeFloatingPanel, etc.
    "api.lua",           -- 3. Supabase, Key System, Cache, Playlist API
    "ui_components.lua", -- 4. Splash, Player de áudio, MusicCard, EditScreen
    "profile.lua",       -- 5. Perfil, Leaderboard, Playlists
    "music_list.lua",    -- 6. Lista de músicas, filtros, publicação
    "main_gui.lua",      -- 7. GUI principal, tabs, main()
}

for _, mod in ipairs(modules) do
    local url = REPO .. mod
    local ok, err = pcall(function()
        loadstring(game:HttpGet(url, true))()
    end)
    if not ok then
        warn("[TMI] Falha ao carregar módulo: " .. mod .. "\n" .. tostring(err))
        return
    end
end
