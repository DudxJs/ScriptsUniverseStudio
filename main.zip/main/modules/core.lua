-- ══════════════════════════════════════════════════════════════
-- 🔧 core.lua — Funções utilitárias puras (sem lógica de negócio)
-- Depende de: config.lua
-- ══════════════════════════════════════════════════════════════

local TMI          = _G.TMI
local TweenService = TMI.TweenService
local RunService   = TMI.RunService
local ICONS        = TMI.ICONS
local RGB_COLORS   = TMI.RGB_COLORS

-- ──────────────────────────────────────────────────────────────
-- 🖼️ makeIcon — cria um ImageLabel ícone filho de um parent
-- ──────────────────────────────────────────────────────────────
local function makeIcon(parent, iconId, size, position, zIndex)
    local img = Instance.new("ImageLabel", parent)
    img.Size                 = size     or UDim2.new(0, 24, 0, 24)
    img.Position             = position or UDim2.new(0.5, -12, 0.5, -12)
    img.BackgroundTransparency = 1
    img.Image                = iconId
    img.ScaleType            = Enum.ScaleType.Fit
    img.ZIndex               = zIndex or 10
    return img
end

-- ──────────────────────────────────────────────────────────────
-- 🔄 spinIcon — rotação contínua (ícone de carregando)
-- ──────────────────────────────────────────────────────────────
local function spinIcon(img)
    local rot = 0
    local conn
    conn = RunService.Heartbeat:Connect(function(dt)
        if not img.Parent then conn:Disconnect(); return end
        rot = (rot + dt * 360) % 360
        img.Rotation = rot
    end)
    return conn
end

-- ──────────────────────────────────────────────────────────────
-- 🔘 makeSwitch — switch animado reutilizável
-- Retorna: { track, knob, stroke, setOn(bool), toggle(), get() }
-- ──────────────────────────────────────────────────────────────
local function makeSwitch(parent, x, y, z, colorOn, onChange)
    colorOn = colorOn or Color3.fromRGB(200, 50, 50)
    local COLOR_OFF_TRACK = Color3.fromRGB(50, 50, 70)
    local COLOR_OFF_KNOB  = Color3.fromRGB(110, 110, 140)
    local COLOR_ON_KNOB   = Color3.new(1, 1, 1)

    local track = Instance.new("TextButton", parent)
    track.Size            = UDim2.new(0, 44, 0, 24)
    track.Position        = UDim2.new(0, x, 0, y)
    track.BackgroundColor3 = COLOR_OFF_TRACK
    track.BorderSizePixel = 0
    track.Text            = ""
    track.ZIndex          = z
    Instance.new("UICorner", track).CornerRadius = UDim.new(1, 0)

    local stroke = Instance.new("UIStroke", track)
    stroke.Color     = Color3.fromRGB(80, 80, 110)
    stroke.Thickness = 1.5

    local knob = Instance.new("Frame", track)
    knob.Size             = UDim2.new(0, 18, 0, 18)
    knob.Position         = UDim2.new(0, 3, 0.5, -9)
    knob.BackgroundColor3 = COLOR_OFF_KNOB
    knob.BorderSizePixel  = 0
    knob.ZIndex           = z + 1
    Instance.new("UICorner", knob).CornerRadius = UDim.new(1, 0)

    local isOn = false
    local tw   = TweenInfo.new(0.22, Enum.EasingStyle.Quad)

    local function setOn(val)
        isOn = val
        if isOn then
            TweenService:Create(track,  tw, { BackgroundColor3 = colorOn }):Play()
            TweenService:Create(stroke, tw, { Color = colorOn }):Play()
            TweenService:Create(knob,   tw, { Position = UDim2.new(1, -21, 0.5, -9), BackgroundColor3 = COLOR_ON_KNOB }):Play()
        else
            TweenService:Create(track,  tw, { BackgroundColor3 = COLOR_OFF_TRACK }):Play()
            TweenService:Create(stroke, tw, { Color = Color3.fromRGB(80, 80, 110) }):Play()
            TweenService:Create(knob,   tw, { Position = UDim2.new(0, 3, 0.5, -9), BackgroundColor3 = COLOR_OFF_KNOB }):Play()
        end
    end

    local function toggle()
        setOn(not isOn)
        if onChange then onChange(isOn) end
    end

    track.MouseButton1Click:Connect(toggle)

    return { track = track, knob = knob, stroke = stroke,
             setOn = setOn, toggle = toggle, get = function() return isOn end }
end

-- ──────────────────────────────────────────────────────────────
-- 🎨 animRGB — anima cor de UIStroke/TextLabel ciclicamente
-- ──────────────────────────────────────────────────────────────
local function animRGB(target, prop, speed)
    prop  = prop  or "Color"
    speed = speed or 1
    local idx = 1
    local function loop()
        if not target.Parent then return end
        idx = idx % #RGB_COLORS + 1
        TweenService:Create(target, TweenInfo.new(speed, Enum.EasingStyle.Sine),
            { [prop] = RGB_COLORS[idx] }):Play()
        task.delay(speed, loop)
    end
    loop()
end

-- ──────────────────────────────────────────────────────────────
-- 🏗️ makeFloatingPanel — painel flutuante reutilizável
--    opts = { zBase, panelSize, panelPos, overlayClose,
--             cornerRadius, gradient, rgbSpeed }
--    buildFn(panel, closePanel, overlay)
-- ──────────────────────────────────────────────────────────────
local function makeFloatingPanel(parent, opts, buildFn)
    opts        = opts or {}
    local z     = opts.zBase        or 30
    local pSize = opts.panelSize    or UDim2.new(0.88, 0, 0, 320)
    local pH    = pSize.Y.Offset
    local pPos  = opts.panelPos     or UDim2.new(0.06, 0, 0.5, -pH/2)
    local cr    = opts.cornerRadius or 18
    local rgbSpd = opts.rgbSpeed    or 1
    local canClose = opts.overlayClose ~= false

    local overlay = Instance.new("TextButton", parent)
    overlay.Name                   = "FloatingOverlay"
    overlay.Size                   = UDim2.new(1, 0, 1, 0)
    overlay.BackgroundColor3       = Color3.fromRGB(0, 0, 0)
    overlay.BackgroundTransparency = 0.45
    overlay.Text                   = ""
    overlay.BorderSizePixel        = 0
    overlay.ZIndex                 = z
    overlay.AutoButtonColor        = false
    Instance.new("UICorner", overlay).CornerRadius = UDim.new(0, 20)

    local panel = Instance.new("Frame", overlay)
    panel.Name                   = "FloatingPanel"
    panel.Size                   = pSize
    panel.Position               = pPos
    panel.BackgroundColor3       = Color3.fromRGB(16, 14, 24)
    panel.BorderSizePixel        = 0
    panel.ZIndex                 = z + 1
    panel.BackgroundTransparency = 1
    Instance.new("UICorner", panel).CornerRadius = UDim.new(0, cr)

    if opts.gradient ~= false then
        local gr = Instance.new("UIGradient", panel)
        gr.Color = ColorSequence.new({
            ColorSequenceKeypoint.new(0, Color3.fromRGB(22, 18, 36)),
            ColorSequenceKeypoint.new(1, Color3.fromRGB(10, 8, 18))
        })
        gr.Rotation = 135
    end

    local border = Instance.new("UIStroke", panel)
    border.Thickness = 2
    border.Color     = RGB_COLORS[1]
    animRGB(border, "Color", rgbSpd)

    local startPos = UDim2.new(pPos.X.Scale, pPos.X.Offset, pPos.Y.Scale, pPos.Y.Offset - 25)
    panel.Position = startPos
    TweenService:Create(panel, TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
        Position               = pPos,
        BackgroundTransparency = 0,
    }):Play()
    TweenService:Create(overlay, TweenInfo.new(0.2), { BackgroundTransparency = 0.45 }):Play()

    local closed = false
    local function closePanel()
        if closed then return end
        closed = true
        TweenService:Create(panel, TweenInfo.new(0.22, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
            Size                 = UDim2.new(pSize.X.Scale, pSize.X.Offset, 0, 0),
            Position             = UDim2.new(pPos.X.Scale, pPos.X.Offset, pPos.Y.Scale, pPos.Y.Offset + pH/2),
            BackgroundTransparency = 1,
        }):Play()
        TweenService:Create(overlay, TweenInfo.new(0.25), { BackgroundTransparency = 1 }):Play()
        task.wait(0.27)
        if overlay and overlay.Parent then overlay:Destroy() end
    end

    overlay.MouseButton1Click:Connect(function()
        if canClose then closePanel() end
    end)

    local hitblock = Instance.new("TextButton", panel)
    hitblock.Size                  = UDim2.new(1, 0, 1, 0)
    hitblock.BackgroundTransparency = 1
    hitblock.Text                  = ""
    hitblock.ZIndex                = z + 1
    hitblock.AutoButtonColor       = false
    hitblock.MouseButton1Click:Connect(function() end)

    if buildFn then buildFn(panel, closePanel, overlay) end
    return closePanel, panel, overlay
end

-- ──────────────────────────────────────────────────────────────
-- 🗂️ makePanelHeader — header padrão (título + botão X)
-- Retorna: header, closeBtn, titleLabel
-- ──────────────────────────────────────────────────────────────
local function makePanelHeader(panel, titleText, zBase)
    local z      = zBase or (panel.ZIndex or 30)
    local header = Instance.new("Frame", panel)
    header.Size             = UDim2.new(1, 0, 0, 46)
    header.BackgroundColor3 = Color3.fromRGB(22, 18, 36)
    header.BorderSizePixel  = 0
    header.ZIndex           = z + 2
    Instance.new("UICorner", header).CornerRadius = UDim.new(0, 18)

    local lbl = Instance.new("TextLabel", header)
    lbl.Size                   = UDim2.new(1, -50, 1, 0)
    lbl.Position               = UDim2.new(0, 14, 0, 0)
    lbl.BackgroundTransparency = 1
    lbl.Text                   = titleText
    lbl.TextColor3             = Color3.fromRGB(200, 185, 255)
    lbl.Font                   = Enum.Font.GothamBold
    lbl.TextSize               = 15
    lbl.TextXAlignment         = Enum.TextXAlignment.Left
    lbl.ZIndex                 = z + 3

    local closeBtn = Instance.new("TextButton", header)
    closeBtn.Size             = UDim2.new(0, 28, 0, 28)
    closeBtn.Position         = UDim2.new(1, -36, 0.5, -14)
    closeBtn.BackgroundColor3 = Color3.fromRGB(180, 40, 40)
    closeBtn.BorderSizePixel  = 0
    closeBtn.Text             = ""
    closeBtn.ZIndex           = z + 3
    Instance.new("UICorner", closeBtn).CornerRadius = UDim.new(1, 0)
    makeIcon(closeBtn, ICONS.CLOSE, UDim2.new(0, 16, 0, 16), UDim2.new(0.5, -8, 0.5, -8), z + 4)

    return header, closeBtn, lbl
end

-- ──────────────────────────────────────────────────────────────
-- 🔢 formatCount — formata números grandes (1k, 1M, 1B)
-- ──────────────────────────────────────────────────────────────
local function formatCount(n)
    n = tonumber(n) or 0
    if     n >= 1e9  then return string.format("%dB", math.floor(n/1e9))
    elseif n >= 1e6  then return string.format("%dM", math.floor(n/1e6))
    elseif n >= 1000 then return string.format("%dk", math.floor(n/1000))
    else return tostring(n) end
end

-- ──────────────────────────────────────────────────────────────
-- 🖼️ normalizeImageUrl — normaliza URL/ID de imagem
-- ──────────────────────────────────────────────────────────────
local function normalizeImageUrl(input, userId)
    if not input or input == "" then
        if userId then
            return "https://www.roblox.com/headshot-thumbnail/image?userId="..tostring(userId).."&width=150&height=150&format=png"
        end
        return ""
    end
    local str = tostring(input):match("^%s*(.-)%s*$")
    if str:match("^https?://")    then return str end
    if str:match("^rbxasset://")  then return str end
    if str:match("^rbxassetid://") then return str end
    if str:match("^%d+$") then
        local assetId = tonumber(str)
        local ok, info = pcall(function()
            return game:GetService("MarketplaceService"):GetProductInfo(assetId, Enum.InfoType.Asset)
        end)
        if ok and info and info.AssetTypeId == 1 then
            return "rbxassetid://" .. str
        else
            if userId then
                return "https://www.roblox.com/headshot-thumbnail/image?userId="..tostring(userId).."&width=150&height=150&format=png"
            end
            return ""
        end
    end
    return str
end

-- ── Exportar ──────────────────────────────────────────────────
TMI.makeIcon          = makeIcon
TMI.spinIcon          = spinIcon
TMI.makeSwitch        = makeSwitch
TMI.animRGB           = animRGB
TMI.makeFloatingPanel = makeFloatingPanel
TMI.makePanelHeader   = makePanelHeader
TMI.formatCount       = formatCount
TMI.normalizeImageUrl = normalizeImageUrl

print("[TMI] core.lua carregado ✓")
