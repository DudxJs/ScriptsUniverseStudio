-- ══════════════════════════════════════════════════════════════
-- 👤 profile.lua — Perfil de usuário, Leaderboard, Playlists
-- Depende de: config.lua, core.lua, api.lua, ui_components.lua
-- ══════════════════════════════════════════════════════════════

local TMI              = _G.TMI
local player           = TMI.player
local TweenService     = TMI.TweenService
local HttpService      = TMI.HttpService
local ICONS            = TMI.ICONS
local RGB_COLORS       = TMI.RGB_COLORS
local _cache           = TMI._cache
local _dirty           = TMI._dirty

local makeIcon            = TMI.makeIcon
local makeFloatingPanel   = TMI.makeFloatingPanel
local makePanelHeader     = TMI.makePanelHeader
local animRGB             = TMI.animRGB
local makeSwitch          = TMI.makeSwitch
local formatCount         = TMI.formatCount
local normalizeImageUrl   = TMI.normalizeImageUrl
local spinIcon            = TMI.spinIcon

local fetchLikeCount          = TMI.fetchLikeCount
local checkPlayerLiked        = TMI.checkPlayerLiked
local giveLike                = TMI.giveLike
local removeLike              = TMI.removeLike
local fetchFollowCount        = TMI.fetchFollowCount
local fetchFollowingCount     = TMI.fetchFollowingCount
local checkIsFollowing        = TMI.checkIsFollowing
local followUser              = TMI.followUser
local unfollowUser            = TMI.unfollowUser
local fetchPlaylists          = TMI.fetchPlaylists
local createPlaylistAPI       = TMI.createPlaylistAPI
local deletePlaylistAPI       = TMI.deletePlaylistAPI
local addSongToPlaylistAPI    = TMI.addSongToPlaylistAPI
local removeSongFromPlaylistAPI = TMI.removeSongFromPlaylistAPI
local sbDeleteMusic           = TMI.sbDeleteMusic

local showKeySystem           = TMI.showKeySystem
local createMusicCard         = TMI.createMusicCard
local createAudioPlayerScreen = TMI.createAudioPlayerScreen
local openEditMusicScreen     = TMI.openEditMusicScreen
local openMoreOptionsMenu     = TMI.openMoreOptionsMenu
local createPlaylistDetailView = TMI.createPlaylistDetailView

local PLAYLIST_SCRIPT_NAME    = TMI.PLAYLIST_SCRIPT_NAME
local SUPABASE_URL            = TMI.SUPABASE_URL
local request                 = TMI.request

local function createProfileView(mainFrame, targetUserData)
    local existingProfile = mainFrame:FindFirstChild("UserProfileFrame")
    if existingProfile then existingProfile:Destroy() end

    local tabFrame      = mainFrame:FindFirstChild("TabFrame")
    local pagesContainer= mainFrame:FindFirstChild("PagesContainer")
    local musicListFrame= mainFrame:FindFirstChild("MusicListFrame")
    local closeButton   = mainFrame:FindFirstChild("CloseButton")
    local tipLabel      = mainFrame:FindFirstChild("TipLabel")
    local musicListWasVisible = musicListFrame and musicListFrame.Visible

    if tabFrame      then tabFrame.Visible       = false end
    if pagesContainer then pagesContainer.Visible = false end
    if musicListFrame then musicListFrame.Visible = false end
    if closeButton   then closeButton.Visible     = false end
    if tipLabel      then tipLabel.Visible        = false end

    -- ── TOP 1 detection (baseado em fama: seguidores × 3 + likes × 2 + músicas × 1) ──
    -- Usa o cache _top1FameUserId que é preenchido pelo updateLeaderboard.
    -- Se ainda não carregou (splash screen), faz fallback sem marcação dourada.
    local isTop1 = (_top1FameUserId ~= nil) and (tostring(targetUserData.UserId) == _top1FameUserId)

    local GOLD1 = Color3.fromRGB(255, 215, 0)
    local GOLD2 = Color3.fromRGB(255, 160, 20)
    local GOLD3 = Color3.fromRGB(180, 110, 0)

    -- ── Frame raiz ───────────────────────────────────────────────
    local profileFrame = Instance.new("Frame")
    profileFrame.Name             = "UserProfileFrame"
    profileFrame.Size             = UDim2.new(1, 0, 1, 0)
    profileFrame.Position         = UDim2.new(1, 0, 0, 0)
    profileFrame.BackgroundColor3 = isTop1 and Color3.fromRGB(30,22,5) or Color3.fromRGB(15,15,20)
    profileFrame.BorderSizePixel  = 0
    profileFrame.ZIndex           = 20
    profileFrame.ClipsDescendants = true
    profileFrame.BackgroundTransparency = 1
    profileFrame.Parent = mainFrame
    Instance.new("UICorner", profileFrame).CornerRadius = UDim.new(0, 20)

    -- Partículas TOP1
    if isTop1 then
        local function spawnGP()
            local p = Instance.new("Frame", profileFrame)
            local sz = math.random(3,8)
            p.Size = UDim2.new(0,sz,0,sz); p.Position = UDim2.fromScale(math.random(0,100)/100, math.random(0,100)/100)
            p.BackgroundColor3 = math.random()>.5 and GOLD1 or GOLD2; p.BackgroundTransparency=math.random(30,60)/100
            p.BorderSizePixel=0; p.ZIndex=19; Instance.new("UICorner",p).CornerRadius=UDim.new(1,0)
            local d=math.random(20,50)/10
            TweenService:Create(p,TweenInfo.new(d,Enum.EasingStyle.Sine,Enum.EasingDirection.InOut),{Position=UDim2.fromScale(math.random(0,100)/100,math.random(0,100)/100),BackgroundTransparency=1}):Play()
            task.delay(d,function() if p and p.Parent then p:Destroy() end end)
        end
        spawn(function() for i=1,16 do spawnGP();wait(0.08) end; while profileFrame.Parent do spawnGP();wait(0.7) end end)
    end

    -- ── Dados do usuário ─────────────────────────────────────────
    local userId      = targetUserData.UserId
    local displayName = targetUserData.DisplayName or "Desconhecido"
    local username    = targetUserData.PlayerName  or "Player"
    local photo       = targetUserData.Foto or ("https://www.roblox.com/headshot-thumbnail/image?userId="..tostring(userId).."&width=150&height=150&format=png")
    local isSelf      = tostring(userId) == tostring(player.UserId)

    local userSongs = {}
    for _, song in ipairs(allMusicData) do
        if tostring(song.UserId) == tostring(userId) then table.insert(userSongs, song) end
    end

    -- ════════════════════════════════════════════════════════════
    --  CAMADA 1 — MINI-HEADER FIXO (sempre visível, ZIndex alto)
    --  Aparece igual ao TikTok ao rolar: fotinho + Seguir + share
    -- ════════════════════════════════════════════════════════════
    local MINI_H = 52
    local miniBar = Instance.new("Frame", profileFrame)
    miniBar.Name             = "MiniBar"
    miniBar.Size             = UDim2.new(1, 0, 0, MINI_H)
    miniBar.Position         = UDim2.new(0, 0, 0, 0)
    miniBar.BackgroundColor3 = isTop1 and Color3.fromRGB(22,16,4) or Color3.fromRGB(18,18,24)
    miniBar.BackgroundTransparency = 1
    miniBar.BorderSizePixel  = 0
    miniBar.ZIndex           = 32
    Instance.new("UICorner", miniBar).CornerRadius = UDim.new(0,14)
    if isTop1 then
        local mb_grad = Instance.new("UIGradient", miniBar)
        mb_grad.Color = ColorSequence.new({ColorSequenceKeypoint.new(0,Color3.fromRGB(40,28,5)), ColorSequenceKeypoint.new(1,Color3.fromRGB(22,16,4))})
    end

    -- Botão voltar (mini bar)
    local backBtn = Instance.new("TextButton", miniBar)
    backBtn.Size = UDim2.new(0,36,0,36); backBtn.Position = UDim2.new(0,8,0.5,-18)
    backBtn.BackgroundTransparency = 1; backBtn.Text = ""; backBtn.ZIndex = 33
    makeIcon(backBtn, ICONS.BACK, UDim2.new(0,22,0,22), UDim2.new(0.5,-11,0.5,-11), 34)
    backBtn.MouseButton1Click:Connect(function()
        local guiBorder = mainFrame:FindFirstChild("BorderFrame")
        if guiBorder then guiBorder.Transparency=0; guiBorder.Thickness=3 end
        local t = TweenService:Create(profileFrame, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {Position = UDim2.new(1,0,0,0)})
        t:Play(); t.Completed:Wait(); profileFrame:Destroy()
        if closeButton   then closeButton.Visible   = true end
        if tabFrame      then tabFrame.Visible      = true end
        if tipLabel      then tipLabel.Visible      = true end
        if musicListWasVisible then
            if musicListFrame and musicListFrame.Parent then musicListFrame.Visible = true end
        else
            if pagesContainer then pagesContainer.Visible = true end
        end
    end)

    -- Mini avatar circular
    local miniAvSize = 34
    local miniAvFrame = Instance.new("Frame", miniBar)
    miniAvFrame.Size = UDim2.new(0,miniAvSize,0,miniAvSize); miniAvFrame.Position = UDim2.new(0.5,-miniAvSize/2,0.5,-miniAvSize/2)
    miniAvFrame.BackgroundColor3 = isTop1 and GOLD1 or Color3.fromRGB(80,80,120); miniAvFrame.BorderSizePixel=0; miniAvFrame.ZIndex=33
    Instance.new("UICorner", miniAvFrame).CornerRadius = UDim.new(1,0)
    local miniAvImg = Instance.new("ImageLabel", miniAvFrame)
    miniAvImg.Size = UDim2.new(1,-2,1,-2); miniAvImg.Position = UDim2.new(0,1,0,1)
    miniAvImg.BackgroundTransparency=1; miniAvImg.Image=normalizeImageUrl(photo,userId); miniAvImg.ZIndex=34
    Instance.new("UICorner", miniAvImg).CornerRadius = UDim.new(1,0)

    -- Botão Seguir na mini bar (só para outros usuários)
    local miniFollowBtn
    if not isSelf then
        miniFollowBtn = Instance.new("TextButton", miniBar)
        miniFollowBtn.Size = UDim2.new(0,80,0,30); miniFollowBtn.Position = UDim2.new(1,-96,0.5,-15)
        miniFollowBtn.BackgroundColor3 = Color3.fromRGB(255,40,80); miniFollowBtn.Text = "Seguir"
        miniFollowBtn.TextColor3 = Color3.fromRGB(255,255,255); miniFollowBtn.Font = Enum.Font.GothamBold
        miniFollowBtn.TextSize = 13; miniFollowBtn.BorderSizePixel = 0; miniFollowBtn.ZIndex = 33
        Instance.new("UICorner", miniFollowBtn).CornerRadius = UDim.new(0,8)
    end

    -- ════════════════════════════════════════════════════════════
    --  CAMADA 2 — TABS FIXAS (logo abaixo do mini bar, ZIndex alto)
    -- ════════════════════════════════════════════════════════════
    local TAB_H = 44
    local tabsBar = Instance.new("Frame", profileFrame)
    tabsBar.Name             = "TabsBar"
    tabsBar.Size             = UDim2.new(1, 0, 0, TAB_H)
    tabsBar.Position         = UDim2.new(0, 0, 0, MINI_H)
    tabsBar.BackgroundColor3 = isTop1 and Color3.fromRGB(18,13,3) or Color3.fromRGB(17,17,22)
    tabsBar.BackgroundTransparency = 1
    tabsBar.BorderSizePixel  = 0
    tabsBar.ZIndex           = 31

    local tabIndicator = Instance.new("Frame", tabsBar)
    tabIndicator.Size             = UDim2.new(0.5, 0, 0, 2)
    tabIndicator.Position         = UDim2.new(0, 0, 1, -2)
    tabIndicator.BackgroundColor3 = isTop1 and GOLD1 or RGB_COLORS[1]
    tabIndicator.BorderSizePixel  = 0; tabIndicator.ZIndex = 32

    local tabMusicas = Instance.new("TextButton", tabsBar)
    tabMusicas.Size = UDim2.new(0.5,0,1,0); tabMusicas.Position = UDim2.new(0,0,0,0)
    tabMusicas.BackgroundTransparency=1; tabMusicas.Text="🎵  Músicas"
    tabMusicas.TextColor3 = isTop1 and GOLD1 or Color3.fromRGB(255,255,255)
    tabMusicas.Font = Enum.Font.GothamBold; tabMusicas.TextSize=13; tabMusicas.ZIndex=32

    local tabPlaylists = Instance.new("TextButton", tabsBar)
    tabPlaylists.Size = UDim2.new(0.5,0,1,0); tabPlaylists.Position = UDim2.new(0.5,0,0,0)
    tabPlaylists.BackgroundTransparency=1; tabPlaylists.Text="📋  Playlists"
    tabPlaylists.TextColor3 = isTop1 and GOLD2 or Color3.fromRGB(150,150,200)
    tabPlaylists.Font = Enum.Font.Gotham; tabPlaylists.TextSize=13; tabPlaylists.ZIndex=32

    -- Linha separadora abaixo das tabs
    local tabsDivider = Instance.new("Frame", tabsBar)
    tabsDivider.Size = UDim2.new(1,0,0,1); tabsDivider.Position = UDim2.new(0,0,1,-1)
    tabsDivider.BackgroundColor3 = isTop1 and GOLD3 or Color3.fromRGB(40,40,58)
    tabsDivider.BorderSizePixel=0; tabsDivider.ZIndex=31

    -- ════════════════════════════════════════════════════════════
    --  CAMADA 3 — SCROLL PRINCIPAL (começa abaixo das tabs fixas)
    --  Contém: header expandido + cards de conteúdo
    -- ════════════════════════════════════════════════════════════
    local FIXED_TOP = MINI_H + TAB_H   -- altura das duas barras fixas
    local profileScroll = Instance.new("ScrollingFrame", profileFrame)
    profileScroll.Name             = "ProfileScroll"
    profileScroll.Size             = UDim2.new(1, 0, 1, -FIXED_TOP)
    profileScroll.Position         = UDim2.new(0, 0, 0, FIXED_TOP)
    profileScroll.BackgroundTransparency = 1
    profileScroll.BorderSizePixel  = 0
    profileScroll.ScrollBarThickness = isTop1 and 4 or 3
    profileScroll.ScrollBarImageColor3 = isTop1 and GOLD1 or RGB_COLORS[1]
    profileScroll.CanvasSize       = UDim2.new(0, 0, 0, 800)
    profileScroll.ZIndex           = 20

    -- ── HEADER EXPANDIDO (dentro do scroll) ─────────────────────
    --  Foto grande · Nome · @ · Stats · Seguir · Bio (TOP1: coroa)
    local BIG_AV = isTop1 and 92 or 82
    local HEADER_INNER_H = isTop1 and 300 or 260   -- altura do bloco header no scroll

    local headerBg = Instance.new("Frame", profileScroll)
    headerBg.Size = UDim2.new(1,0,0,HEADER_INNER_H); headerBg.Position = UDim2.new(0,0,0,0)
    headerBg.BackgroundColor3 = isTop1 and Color3.fromRGB(22,16,4) or Color3.fromRGB(25,25,35)
    headerBg.BorderSizePixel=0; headerBg.ZIndex=21
    headerBg.BackgroundTransparency = 1
    Instance.new("UICorner", headerBg).CornerRadius = UDim.new(0,14)
    local hGrad = Instance.new("UIGradient", headerBg)
    if isTop1 then
        hGrad.Color = ColorSequence.new({
            ColorSequenceKeypoint.new(0, Color3.fromRGB(40,28,5)),
            ColorSequenceKeypoint.new(1, Color3.fromRGB(22,16,4))
        })
        TweenService:Create(hGrad, TweenInfo.new(5,Enum.EasingStyle.Linear,Enum.EasingDirection.InOut,-1),{Rotation=360}):Play()
    else
        hGrad.Color = ColorSequence.new({
            ColorSequenceKeypoint.new(0, Color3.fromRGB(30,30,45)),
            ColorSequenceKeypoint.new(1, Color3.fromRGB(18,18,28))
        })
    end

    -- Coroa TOP1
    if isTop1 then
        local crown = Instance.new("TextLabel", profileScroll)
        crown.Size=UDim2.new(0,50,0,36); crown.Position=UDim2.new(0.5,-25,0,8)
        crown.BackgroundTransparency=1; crown.Text="👑"; crown.TextSize=28
        crown.Font=Enum.Font.GothamBold; crown.ZIndex=25
        spawn(function()
            while crown.Parent do
                TweenService:Create(crown,TweenInfo.new(0.6,Enum.EasingStyle.Sine,Enum.EasingDirection.InOut),{Rotation=12}):Play(); wait(0.6)
                TweenService:Create(crown,TweenInfo.new(0.6,Enum.EasingStyle.Sine,Enum.EasingDirection.InOut),{Rotation=-12}):Play(); wait(0.6)
            end
        end)
    end

    -- Anel dourado TOP1
    local avTopY = isTop1 and 46 or 18
    if isTop1 then
        local ring = Instance.new("Frame", profileScroll)
        ring.Size=UDim2.new(0,BIG_AV+14,0,BIG_AV+14); ring.Position=UDim2.new(0.5,-(BIG_AV+14)/2,0,avTopY-7)
        ring.BackgroundColor3=GOLD1; ring.BorderSizePixel=0; ring.ZIndex=23
        Instance.new("UICorner",ring).CornerRadius=UDim.new(1,0)
        local rg=Instance.new("UIGradient",ring)
        rg.Color=ColorSequence.new({ColorSequenceKeypoint.new(0,GOLD1),ColorSequenceKeypoint.new(0.5,Color3.fromRGB(255,255,180)),ColorSequenceKeypoint.new(1,GOLD2)})
        TweenService:Create(rg,TweenInfo.new(3,Enum.EasingStyle.Linear,Enum.EasingDirection.InOut,-1),{Rotation=360}):Play()
        spawn(function()
            while ring.Parent do
                TweenService:Create(ring,TweenInfo.new(1,Enum.EasingStyle.Sine,Enum.EasingDirection.InOut),{Size=UDim2.new(0,BIG_AV+20,0,BIG_AV+20),Position=UDim2.new(0.5,-(BIG_AV+20)/2,0,avTopY-10)}):Play(); wait(1)
                TweenService:Create(ring,TweenInfo.new(1,Enum.EasingStyle.Sine,Enum.EasingDirection.InOut),{Size=UDim2.new(0,BIG_AV+14,0,BIG_AV+14),Position=UDim2.new(0.5,-(BIG_AV+14)/2,0,avTopY-7)}):Play(); wait(1)
            end
        end)
    end

    -- Foto grande
    local bigAv = Instance.new("ImageLabel", profileScroll)
    bigAv.Size=UDim2.new(0,BIG_AV,0,BIG_AV); bigAv.Position=UDim2.new(0.5,-BIG_AV/2,0,avTopY)
    bigAv.BackgroundTransparency=1; bigAv.Image=normalizeImageUrl(photo,userId); bigAv.ZIndex=25
    Instance.new("UICorner",bigAv).CornerRadius=UDim.new(1,0)
    local avStroke=Instance.new("UIStroke",bigAv); avStroke.Color=isTop1 and GOLD1 or Color3.fromRGB(255,255,255)
    avStroke.Thickness=isTop1 and 3 or 2; avStroke.Transparency=isTop1 and 0 or 0.4
    if isTop1 then TweenService:Create(avStroke,TweenInfo.new(1,Enum.EasingStyle.Sine,Enum.EasingDirection.InOut,-1,true),{Transparency=0.5}):Play() end

    -- Nome (DisplayName)
    local nameY = avTopY + BIG_AV + 10
    local dName = Instance.new("TextLabel", profileScroll)
    dName.Size=UDim2.new(1,-20,0,24); dName.Position=UDim2.new(0,10,0,nameY)
    dName.BackgroundTransparency=1; dName.Text=displayName
    dName.TextColor3=isTop1 and GOLD1 or Color3.fromRGB(255,255,255)
    dName.Font=Enum.Font.GothamBold; dName.TextSize=isTop1 and 20 or 18; dName.ZIndex=25
    if isTop1 then
        local ns=Instance.new("UIStroke",dName); ns.Thickness=1.2; ns.Color=GOLD3
        TweenService:Create(ns,TweenInfo.new(1.5,Enum.EasingStyle.Sine,Enum.EasingDirection.InOut,-1,true),{Transparency=0.5}):Play()
    end

    -- @username
    local uNameY = nameY + 26
    local uName = Instance.new("TextLabel", profileScroll)
    uName.Size=UDim2.new(1,-20,0,18); uName.Position=UDim2.new(0,10,0,uNameY)
    uName.BackgroundTransparency=1; uName.Text="@"..username
    uName.TextColor3=isTop1 and GOLD2 or Color3.fromRGB(150,150,150)
    uName.Font=Enum.Font.Gotham; uName.TextSize=13; uName.ZIndex=25

    -- Stats (Seguindo | Seguidores | Curtidas) — igual TikTok
    local statsY = uNameY + 26
    local function makeStat(parent, value, label, xFrac, color)
        local f = Instance.new("Frame", parent)
        f.Size=UDim2.new(0,80,0,46); f.Position=UDim2.new(xFrac,-40,0,0)
        f.BackgroundTransparency=1; f.ZIndex=25
        local vL=Instance.new("TextLabel",f)
        vL.Size=UDim2.new(1,0,0,26); vL.BackgroundTransparency=1; vL.Text=tostring(value)
        vL.TextColor3=color or (isTop1 and GOLD1 or Color3.fromRGB(255,255,255))
        vL.Font=Enum.Font.GothamBold; vL.TextSize=16; vL.ZIndex=26
        local kL=Instance.new("TextLabel",f)
        kL.Size=UDim2.new(1,0,0,16); kL.Position=UDim2.new(0,0,0,28)
        kL.BackgroundTransparency=1; kL.Text=label
        kL.TextColor3=isTop1 and GOLD2 or Color3.fromRGB(130,130,160)
        kL.Font=Enum.Font.Gotham; kL.TextSize=11; kL.ZIndex=26
        -- Separadores verticais
        if xFrac < 0.9 then
            local sep=Instance.new("Frame",f)
            sep.Size=UDim2.new(0,1,0,28); sep.Position=UDim2.new(1,0,0,8)
            sep.BackgroundColor3=isTop1 and GOLD3 or Color3.fromRGB(55,55,70)
            sep.BorderSizePixel=0; sep.ZIndex=25
        end
        return vL
    end
    local statsRow = Instance.new("Frame", profileScroll)
    statsRow.Size=UDim2.new(1,-20,0,46); statsRow.Position=UDim2.new(0,10,0,statsY)
    statsRow.BackgroundTransparency=1; statsRow.ZIndex=25
    local seguindoVal = makeStat(statsRow, "...",      "Seguindo",   0.17)
    local seguidoresVal= makeStat(statsRow, "...",    "Seguidores", 0.50)
    local curtidosVal  = makeStat(statsRow, "...",    "Curtidas",   0.83, Color3.fromRGB(255,180,80))

    -- Seguidores e Seguindo: lidos direto do cache (síncronos)
    -- Para o player local fetchFollowingCount é síncrono;
    -- para outros players faz request pontual dentro de task.spawn
    task.defer(function()
        fetchFollowCount(tostring(userId), function(cnt)
            if seguidoresVal and seguidoresVal.Parent then
                seguidoresVal.Text = formatCount(cnt)
            end
        end)
        fetchFollowingCount(tostring(userId), function(cnt)
            if seguindoVal and seguindoVal.Parent then
                seguindoVal.Text = formatCount(cnt)
            end
        end)
        -- Likes totais: soma do cache (síncrono, sem request)
        local total = 0
        for _, song in ipairs(userSongs) do
            total += (_cache.likesMap[tostring(song.ID_Musica)] or 0)
        end
        if curtidosVal and curtidosVal.Parent then
            curtidosVal.Text = formatCount(total)
        end
    end)

    -- Botão Seguir / Seguindo (grande, abaixo das stats)
    local followBtnY = statsY + 54
    if not isSelf then
        local followBtn = Instance.new("TextButton", profileScroll)
        followBtn.Size=UDim2.new(0,130,0,34); followBtn.Position=UDim2.new(0.5,-65,0,followBtnY)
        followBtn.BackgroundColor3=Color3.fromRGB(255,40,80); followBtn.Text="Seguir"
        followBtn.TextColor3=Color3.fromRGB(255,255,255); followBtn.Font=Enum.Font.GothamBold
        followBtn.TextSize=14; followBtn.BorderSizePixel=0; followBtn.ZIndex=25
        Instance.new("UICorner",followBtn).CornerRadius=UDim.new(0,8)

        local isFollowing=false; local followLoading=false
        local function updateFBtn(f)
            isFollowing=f
            followBtn.Text = f and "Seguindo ✓" or "Seguir"
            followBtn.BackgroundColor3 = f and Color3.fromRGB(35,35,55) or Color3.fromRGB(255,40,80)
            if miniFollowBtn and miniFollowBtn.Parent then
                miniFollowBtn.Text = f and "Seguindo" or "Seguir"
                miniFollowBtn.BackgroundColor3 = f and Color3.fromRGB(55,55,75) or Color3.fromRGB(255,40,80)
            end
        end
        checkIsFollowing(tostring(userId), function(f) updateFBtn(f) end)
        local function doFollow()
            if followLoading then return end; followLoading=true
            if isFollowing then
                unfollowUser(tostring(userId), function(ok) followLoading=false
                    if ok then updateFBtn(false); fetchFollowCount(tostring(userId), function(cnt)
                        if seguidoresVal and seguidoresVal.Parent then seguidoresVal.Text=formatCount(cnt) end
                    end) end
                end)
            else
                followUser(tostring(userId), function(ok) followLoading=false
                    if ok then updateFBtn(true); fetchFollowCount(tostring(userId), function(cnt)
                        if seguidoresVal and seguidoresVal.Parent then seguidoresVal.Text=formatCount(cnt) end
                    end) end
                end)
            end
        end
        followBtn.MouseButton1Click:Connect(doFollow)
        if miniFollowBtn then miniFollowBtn.MouseButton1Click:Connect(doFollow) end
    end

    -- Badge TOP1
    if isTop1 then
        local badge = Instance.new("Frame", profileScroll)
        badge.Size=UDim2.new(0,86,0,24); badge.Position=UDim2.new(0,10,0,60)
        badge.BackgroundColor3=Color3.fromRGB(45,30,0); badge.ZIndex=26
        Instance.new("UICorner",badge).CornerRadius=UDim.new(0,8)
        Instance.new("UIStroke",badge).Color=GOLD1
        local bg2=Instance.new("UIGradient",badge)
        bg2.Color=ColorSequence.new({ColorSequenceKeypoint.new(0,Color3.fromRGB(60,42,0)),ColorSequenceKeypoint.new(1,Color3.fromRGB(35,24,0))})
        local bL=Instance.new("TextLabel",badge)
        bL.Size=UDim2.new(1,0,1,0); bL.BackgroundTransparency=1; bL.Text="👑 TOP 1"
        bL.TextColor3=GOLD1; bL.Font=Enum.Font.GothamBold; bL.TextSize=12; bL.ZIndex=27
        TweenService:Create(bL,TweenInfo.new(1.4,Enum.EasingStyle.Sine,Enum.EasingDirection.InOut,-1,true),{TextColor3=Color3.fromRGB(255,255,200)}):Play()
    end

    -- Calcular HEADER_INNER_H real
    local contentStartY = (isSelf and (followBtnY) or (followBtnY + 44)) + 16
    -- reajusta o headerBg
    headerBg.Size = UDim2.new(1,0,0,contentStartY - 8)

    -- ── CONTEÚDO DAS ABAS ────────────────────────────────────────
    local isOwnProfile = isSelf
    local currentTab   = "musicas"

    local function clearContent()
        for _, ch in ipairs(profileScroll:GetChildren()) do
            if ch ~= headerBg and ch.ClassName ~= "UICorner" then
                local py = ch.Position.Y.Offset
                if py >= contentStartY - 2 then ch:Destroy() end
            end
        end
    end

    -- Músicas
    local function renderMusicTab()
        local yPos = contentStartY
        if #userSongs > 0 then
            for _, song in ipairs(userSongs) do
                if isTop1 then
                    -- ── Estrutura IDÊNTICA ao createMusicCard, com visual dourado ──
                    local card = Instance.new("Frame", profileScroll)
                    card.Name = "MusicCard"
                    card.Size = UDim2.new(1,-20,0,100)
                    card.Position = UDim2.new(0,10,0,yPos+20)
                    card.BackgroundColor3 = Color3.fromRGB(28,20,5)
                    card.BorderSizePixel = 0; card.ZIndex = 22
                    Instance.new("UICorner",card).CornerRadius = UDim.new(0,15)
                    -- Gradiente dourado (substituição do fundo escuro original)
                    local cG = Instance.new("UIGradient",card)
                    cG.Color = ColorSequence.new({
                        ColorSequenceKeypoint.new(0, Color3.fromRGB(38,28,6)),
                        ColorSequenceKeypoint.new(1, Color3.fromRGB(22,16,4))
                    }); cG.Rotation = 135
                    -- Borda dourada animada
                    local cS = Instance.new("UIStroke",card); cS.Color=GOLD2; cS.Thickness=1.5; cS.Transparency=0.3
                    task.spawn(function()
                        while card.Parent do
                            TweenService:Create(cS, TweenInfo.new(1,Enum.EasingStyle.Sine), {Color=GOLD1, Transparency=0.1}):Play()
                            task.wait(1)
                            TweenService:Create(cS, TweenInfo.new(1,Enum.EasingStyle.Sine), {Color=GOLD3, Transparency=0.4}):Play()
                            task.wait(1)
                        end
                    end)
                    -- Entrada animada (igual ao original)
                    TweenService:Create(card,TweenInfo.new(0.3,Enum.EasingStyle.Quad,Enum.EasingDirection.Out),
                        {Position=UDim2.new(0,10,0,yPos),BackgroundTransparency=0}):Play()

                    -- ── Avatar (mesmas dimensões do original: 70×70, pos 15,15) ──
                    local mAF = Instance.new("Frame",card)
                    mAF.Name = "AvatarFrame"
                    mAF.Size = UDim2.new(0,70,0,70); mAF.Position = UDim2.new(0,15,0,15)
                    mAF.BackgroundColor3 = GOLD1; mAF.BorderSizePixel=0; mAF.ZIndex=23
                    Instance.new("UICorner",mAF).CornerRadius = UDim.new(1,0)
                    local mAI = Instance.new("ImageLabel",mAF)
                    mAI.Size=UDim2.new(1,-4,1,-4); mAI.Position=UDim2.new(0,2,0,2)
                    mAI.BackgroundTransparency=1; mAI.Image=normalizeImageUrl(song.Foto,song.UserId)
                    mAI.ZIndex=24; Instance.new("UICorner",mAI).CornerRadius=UDim.new(1,0)

                    -- ── Nome (pos 120,15 — igual ao original) ──
                    local mN = Instance.new("TextLabel",card)
                    mN.Name="MusicName"; mN.Size=UDim2.new(0,230,0,25); mN.Position=UDim2.new(0,120,0,15)
                    mN.BackgroundTransparency=1; mN.Text=(song.Nome or "Sem nome")
                    mN.TextColor3=GOLD1; mN.TextSize=16; mN.Font=Enum.Font.GothamBold
                    mN.TextXAlignment=Enum.TextXAlignment.Left; mN.TextTruncate=Enum.TextTruncate.AtEnd; mN.ZIndex=23
                    makeIcon(card, ICONS.MUSIC_NOTE, UDim2.new(0,14,0,14), UDim2.new(0,103,0,20), 24)

                    -- ── Categoria (pos 118,40 — igual ao original) ──
                    local mC = Instance.new("TextLabel",card)
                    mC.Name="MusicCategory"; mC.Size=UDim2.new(0,232,0,20); mC.Position=UDim2.new(0,118,0,40)
                    mC.BackgroundTransparency=1; mC.Text=(song.Categoria or "Outros")
                    mC.TextColor3=GOLD3; mC.TextSize=12; mC.Font=Enum.Font.Gotham
                    mC.TextXAlignment=Enum.TextXAlignment.Left; mC.ZIndex=23
                    makeIcon(card, ICONS.IC_CATEGORY, UDim2.new(0,13,0,13), UDim2.new(0,102,0,44), 24)

                    -- ── Publicador (pos 118,57 — igual ao original) ──
                    local mP = Instance.new("TextLabel",card)
                    mP.Name="PublisherName"; mP.Size=UDim2.new(0,232,0,20); mP.Position=UDim2.new(0,118,0,57)
                    mP.BackgroundTransparency=1; mP.Text="Por: "..(song.DisplayName or song.PlayerName or "Usuário")
                    mP.TextColor3=GOLD2; mP.TextSize=14; mP.Font=Enum.Font.Gotham
                    mP.TextXAlignment=Enum.TextXAlignment.Left; mP.TextTruncate=Enum.TextTruncate.AtEnd; mP.ZIndex=23
                    makeIcon(card, ICONS.IC_PLAYER, UDim2.new(0,14,0,14), UDim2.new(0,101,0,62), 24)

                    -- ── Data (pos 118,78 — igual ao original) ──
                    local mDt = Instance.new("TextLabel",card)
                    mDt.Name="DateLabel"; mDt.Size=UDim2.new(0,110,0,15); mDt.Position=UDim2.new(0,118,0,78)
                    mDt.BackgroundTransparency=1; mDt.Text=string.sub(tostring(song.Data or ""),1,10)
                    mDt.TextColor3=GOLD3; mDt.TextSize=11; mDt.Font=Enum.Font.Gotham
                    mDt.TextXAlignment=Enum.TextXAlignment.Left; mDt.ZIndex=23
                    makeIcon(card, ICONS.IC_DATE, UDim2.new(0,12,0,12), UDim2.new(0,102,0,80), 24)

                    -- ── Badge ID auto-size (igual ao original, cor dourada) ──
                    local mIdBadge = Instance.new("Frame",card)
                    mIdBadge.Name="MusicIdBadge"; mIdBadge.AutomaticSize=Enum.AutomaticSize.X
                    mIdBadge.Size=UDim2.new(0,0,0,25); mIdBadge.Position=UDim2.new(1,-10,0,37)
                    mIdBadge.AnchorPoint=Vector2.new(1,0); mIdBadge.BackgroundColor3=Color3.fromRGB(40,28,4)
                    mIdBadge.BorderSizePixel=0; mIdBadge.ZIndex=23
                    Instance.new("UICorner",mIdBadge).CornerRadius=UDim.new(0,8)
                    Instance.new("UIStroke",mIdBadge).Color=GOLD3
                    local mIdPad=Instance.new("UIPadding",mIdBadge)
                    mIdPad.PaddingLeft=UDim.new(0,4); mIdPad.PaddingRight=UDim.new(0,6)
                    local mIdList=Instance.new("UIListLayout",mIdBadge)
                    mIdList.FillDirection=Enum.FillDirection.Horizontal
                    mIdList.VerticalAlignment=Enum.VerticalAlignment.Center
                    mIdList.SortOrder=Enum.SortOrder.LayoutOrder; mIdList.Padding=UDim.new(0,3)
                    local mIdIco=Instance.new("ImageLabel",mIdBadge)
                    mIdIco.LayoutOrder=1; mIdIco.Size=UDim2.new(0,13,0,13)
                    mIdIco.BackgroundTransparency=1; mIdIco.Image=ICONS.IC_ID; mIdIco.ScaleType=Enum.ScaleType.Fit; mIdIco.ZIndex=24
                    local mIdTxt=Instance.new("TextLabel",mIdBadge)
                    mIdTxt.LayoutOrder=2; mIdTxt.AutomaticSize=Enum.AutomaticSize.X
                    mIdTxt.Size=UDim2.new(0,0,1,0); mIdTxt.BackgroundTransparency=1
                    mIdTxt.Text=tostring(song.ID_Musica or "N/A"); mIdTxt.TextColor3=GOLD2
                    mIdTxt.TextSize=12; mIdTxt.Font=Enum.Font.GothamBold; mIdTxt.ZIndex=24

                    -- ── Botão copiar (pos igual ao original: 1,-35, 0,65) ──
                    local mCp=Instance.new("ImageButton",card); mCp.Size=UDim2.new(0,25,0,25); mCp.Position=UDim2.new(1,-35,0,65)
                    mCp.BackgroundColor3=Color3.fromRGB(50,35,0); mCp.BorderSizePixel=0
                    mCp.Image=ICONS.COPY; mCp.ImageColor3=GOLD1; mCp.ScaleType=Enum.ScaleType.Fit; mCp.ZIndex=24
                    mCp.BackgroundTransparency=1
                    Instance.new("UICorner",mCp).CornerRadius=UDim.new(0,6)
                    mCp.MouseButton1Click:Connect(function()
                        if setclipboard then setclipboard(tostring(song.ID_Musica))
                            mCp.Image=ICONS.OK; mCp.ImageColor3=Color3.fromRGB(100,255,150)
                            task.wait(1.5); mCp.Image=ICONS.COPY; mCp.ImageColor3=GOLD1
                        end
                    end)

                    -- ── Botão 3 pontinhos (pos igual ao original: 1,-70, 0,65) ──
                    local mMr=Instance.new("ImageButton",card); mMr.Size=UDim2.new(0,25,0,25); mMr.Position=UDim2.new(1,-70,0,65)
                    mMr.BackgroundColor3=Color3.fromRGB(50,35,0); mMr.BorderSizePixel=0
                    mMr.Image=ICONS.MORE; mMr.ImageColor3=GOLD1; mMr.ScaleType=Enum.ScaleType.Fit; mMr.ZIndex=24
                    mMr.BackgroundTransparency=1
                    Instance.new("UICorner",mMr).CornerRadius=UDim.new(0,6)
                    mMr.MouseButton1Click:Connect(function()
                        local rf=card:FindFirstAncestor("MainFrame"); if rf then openMoreOptionsMenu(rf, song) end
                    end)

                    -- ── Like (pos igual ao original: 0,8, 1,-34) ──
                    local mLk=Instance.new("ImageButton",card)
                    mLk.Name="LikeButton"; mLk.Size=UDim2.new(0,28,0,28); mLk.Position=UDim2.new(0,8,1,-34)
                    mLk.BackgroundTransparency=1; mLk.BorderSizePixel=0
                    mLk.Image=ICONS.LIKE_OFF; mLk.ScaleType=Enum.ScaleType.Fit; mLk.ZIndex=24
                    local mLkCnt=Instance.new("TextLabel",card); mLkCnt.Size=UDim2.new(0,28,0,28)
                    mLkCnt.Position=UDim2.new(0,8,1,-34); mLkCnt.BackgroundTransparency=1
                    mLkCnt.Text="..."; mLkCnt.TextColor3=Color3.fromRGB(255,255,255)
                    mLkCnt.Font=Enum.Font.GothamBold; mLkCnt.TextSize=9
                    mLkCnt.TextXAlignment=Enum.TextXAlignment.Center; mLkCnt.TextYAlignment=Enum.TextYAlignment.Center
                    mLkCnt.ZIndex=25
                    local mLkActive,mLkLoading=false,false
                    local mSongIdStr=tostring(song.ID_Musica)
                    local function mUpdLike(liked,count)
                        mLkActive=liked; mLk.Image=liked and ICONS.LIKE_ON or ICONS.LIKE_OFF
                        mLkCnt.TextColor3=liked and Color3.fromRGB(0,0,0) or Color3.fromRGB(255,255,255)
                        mLkCnt.Text=formatCount(count)
                    end
                    checkPlayerLiked(mSongIdStr,function(liked) fetchLikeCount(mSongIdStr,function(count) if card and card.Parent then mUpdLike(liked,count) end end) end)
                    mLk.MouseButton1Click:Connect(function()
                        if mLkLoading then return end; mLkLoading=true
                        if mLkActive then
                            removeLike(mSongIdStr,function(ok) mLkLoading=false; if ok then fetchLikeCount(mSongIdStr,function(ct) if card and card.Parent then mUpdLike(false,ct) end end) end end)
                        else
                            giveLike(mSongIdStr,function(ok) mLkLoading=false; if ok then fetchLikeCount(mSongIdStr,function(ct) if card and card.Parent then mUpdLike(true,ct) end end) end end)
                        end
                    end)
                    yPos = yPos + 110
                else
                    createMusicCard(profileScroll, song, yPos, nil)
                    yPos = yPos + 110
                end
            end
        else
            local em=Instance.new("TextLabel",profileScroll)
            em.Size=UDim2.new(1,0,0,50); em.Position=UDim2.new(0,0,0,yPos+14)
            em.BackgroundTransparency=1; em.Text="Este usuário ainda não publicou músicas."
            em.TextColor3=isTop1 and GOLD3 or Color3.fromRGB(100,100,100)
            em.Font=Enum.Font.Gotham; em.TextSize=14; em.ZIndex=22; yPos=yPos+70
        end
        profileScroll.CanvasSize = UDim2.new(0,0,0,yPos+20)
    end

    -- Playlists
    local function renderPlaylistTab()
        local pyp = contentStartY
        if isOwnProfile then
            local newPlBtn=Instance.new("TextButton",profileScroll)
            newPlBtn.Size=UDim2.new(1,-20,0,36); newPlBtn.Position=UDim2.new(0,10,0,pyp)
            newPlBtn.BackgroundColor3=Color3.fromRGB(50,30,90); newPlBtn.BorderSizePixel=0
            newPlBtn.Text="✨ Nova Playlist"; newPlBtn.TextColor3=Color3.fromRGB(190,160,255)
            newPlBtn.Font=Enum.Font.GothamBold; newPlBtn.TextSize=13; newPlBtn.ZIndex=23
            Instance.new("UICorner",newPlBtn).CornerRadius=UDim.new(0,10)
            Instance.new("UIStroke",newPlBtn).Color=Color3.fromRGB(100,60,180)
            newPlBtn.MouseButton1Click:Connect(function()
                createNewPlaylistModal(mainFrame, function(name, imageUrl)
                    createPlaylistKeyPanel(mainFrame, function()
                        playlistKeyUnlocked=true
                        createPlaylistAPI(name, imageUrl, function(ok, idOrErr)
                            if ok then
                                table.insert(playerPlaylists,{PlaylistId=idOrErr,PlaylistName=name,OwnerId=tostring(player.UserId),OwnerName=player.Name,Songs={},ImageUrl=imageUrl})
                                playlistKeyUnlocked=false
                                createProfileView(mainFrame, targetUserData)
                            end
                        end)
                    end, nil)
                end)
            end)
            pyp = pyp + 44
        end

        local plLoadLbl=Instance.new("TextLabel",profileScroll)
        plLoadLbl.Size=UDim2.new(1,-20,0,30); plLoadLbl.Position=UDim2.new(0,10,0,pyp)
        plLoadLbl.BackgroundTransparency=1; plLoadLbl.Text="Carregando playlists..."
        plLoadLbl.TextColor3=Color3.fromRGB(130,120,165); plLoadLbl.Font=Enum.Font.Gotham
        plLoadLbl.TextSize=13; plLoadLbl.ZIndex=22
        local _plIco=makeIcon(plLoadLbl,ICONS.LOADING,UDim2.new(0,16,0,16),UDim2.new(0,6,0.5,-8),23)
        spinIcon(_plIco)
        profileScroll.CanvasSize=UDim2.new(0,0,0,pyp+60)

        local function renderCards(pls)
            plLoadLbl:Destroy()
            if #pls==0 then
                local noL=Instance.new("TextLabel",profileScroll)
                noL.Size=UDim2.new(1,-20,0,30); noL.Position=UDim2.new(0,10,0,pyp)
                noL.BackgroundTransparency=1; noL.Text=isOwnProfile and "Você não tem playlists. Crie uma!" or "Este player não tem playlists."
                noL.TextColor3=Color3.fromRGB(120,110,155); noL.Font=Enum.Font.Gotham; noL.TextSize=13; noL.ZIndex=22
                profileScroll.CanvasSize=UDim2.new(0,0,0,pyp+60); return
            end
            local cy=pyp
            for _, pl in ipairs(pls) do
                local plCard=Instance.new("Frame",profileScroll)
                plCard.Name="PlCard_"..tostring(pl.PlaylistId)
                plCard.Size=UDim2.new(1,-20,0,64); plCard.Position=UDim2.new(0,10,0,cy)
                plCard.BackgroundColor3=Color3.fromRGB(22,18,34); plCard.BorderSizePixel=0; plCard.ZIndex=22
                Instance.new("UICorner",plCard).CornerRadius=UDim.new(0,14)
                local pcS=Instance.new("UIStroke",plCard); pcS.Color=Color3.fromRGB(70,50,110); pcS.Thickness=1.5
                local pcG=Instance.new("UIGradient",plCard)
                pcG.Color=ColorSequence.new({ColorSequenceKeypoint.new(0,Color3.fromRGB(30,22,48)),ColorSequenceKeypoint.new(1,Color3.fromRGB(16,12,28))}); pcG.Rotation=135
                -- ícone
                if pl.ImageUrl and pl.ImageUrl~="" then
                    local pI=Instance.new("ImageLabel",plCard); pI.Size=UDim2.new(0,44,0,44); pI.Position=UDim2.new(0,10,0.5,-22)
                    pI.BackgroundTransparency=1; pI.Image=pl.ImageUrl; pI.ScaleType=Enum.ScaleType.Crop; pI.ZIndex=23
                    Instance.new("UICorner",pI).CornerRadius=UDim.new(0,10)
                else
                    local pF=Instance.new("Frame",plCard); pF.Size=UDim2.new(0,44,0,44); pF.Position=UDim2.new(0,10,0.5,-22)
                    pF.BackgroundColor3=Color3.fromRGB(60,35,100); pF.BorderSizePixel=0; pF.ZIndex=23
                    Instance.new("UICorner",pF).CornerRadius=UDim.new(0,10)
                    local pFG=Instance.new("UIGradient",pF); pFG.Color=ColorSequence.new({ColorSequenceKeypoint.new(0,Color3.fromRGB(80,45,140)),ColorSequenceKeypoint.new(1,Color3.fromRGB(40,25,80))})
                    local pFL=Instance.new("TextLabel",pF); pFL.Size=UDim2.new(1,0,1,0); pFL.BackgroundTransparency=1; pFL.Text="🎵"; pFL.TextSize=22; pFL.ZIndex=24
                end
                local pNL=Instance.new("TextLabel",plCard); pNL.Name="PlaylistNameLbl"
                pNL.Size=UDim2.new(1,-140,0,22); pNL.Position=UDim2.new(0,64,0,12)
                pNL.BackgroundTransparency=1; pNL.Text=pl.PlaylistName or "Playlist"
                pNL.TextColor3=Color3.fromRGB(215,205,255); pNL.Font=Enum.Font.GothamBold; pNL.TextSize=14
                pNL.TextXAlignment=Enum.TextXAlignment.Left; pNL.TextTruncate=Enum.TextTruncate.AtEnd; pNL.ZIndex=23
                local sc=#(pl.Songs or {})
                local pCL=Instance.new("TextLabel",plCard); pCL.Name="SongCountLbl"
                pCL.Size=UDim2.new(1,-140,0,18); pCL.Position=UDim2.new(0,64,0,34)
                pCL.BackgroundTransparency=1; pCL.Text=sc..(sc==1 and " música" or " músicas")
                pCL.TextColor3=Color3.fromRGB(140,125,180); pCL.Font=Enum.Font.Gotham; pCL.TextSize=12
                pCL.TextXAlignment=Enum.TextXAlignment.Left; pCL.ZIndex=23
                -- botão ver
                local vBtn=Instance.new("TextButton",plCard)
                vBtn.Size=UDim2.new(0,52,0,26); vBtn.Position=UDim2.new(1,-(isOwnProfile and 98 or 60),0.5,-13)
                vBtn.BackgroundColor3=Color3.fromRGB(50,80,160); vBtn.BorderSizePixel=0
                vBtn.Text="▶ Ver"; vBtn.TextColor3=Color3.fromRGB(255,255,255)
                vBtn.Font=Enum.Font.GothamBold; vBtn.TextSize=12; vBtn.ZIndex=23
                Instance.new("UICorner",vBtn).CornerRadius=UDim.new(0,8)
                local capPl=pl
                vBtn.MouseButton1Click:Connect(function()
                    createPlaylistDetailView(profileScroll, capPl, isOwnProfile, function()
                        createProfileView(mainFrame, targetUserData)
                    end, tabsBar)
                end)
                -- botão deletar (só dono)
                if isOwnProfile then
                    local dBtn=Instance.new("ImageButton",plCard)
                    dBtn.Size=UDim2.new(0,26,0,26); dBtn.Position=UDim2.new(1,-40,0.5,-13)
                    dBtn.BackgroundColor3=Color3.fromRGB(100,28,28); dBtn.BorderSizePixel=0
                    dBtn.Image=ICONS.DELETE; dBtn.ScaleType=Enum.ScaleType.Fit; dBtn.ZIndex=23
                    Instance.new("UICorner",dBtn).CornerRadius=UDim.new(0,6)
                    vBtn.Position=UDim2.new(1,-98,0.5,-13)
                    local capId=pl.PlaylistId
                    dBtn.MouseButton1Click:Connect(function()
                        dBtn.Image=ICONS.LOADING; spinIcon(dBtn)
                        for i,p in ipairs(playerPlaylists) do if p.PlaylistId==capId then table.remove(playerPlaylists,i);break end end
                        TweenService:Create(plCard,TweenInfo.new(0.25,Enum.EasingStyle.Quad,Enum.EasingDirection.In),{Size=UDim2.new(1,-20,0,0),BackgroundTransparency=1}):Play()
                        task.delay(0.25,function() if plCard and plCard.Parent then plCard:Destroy() end end)
                        deletePlaylistAPI(capId, function(ok,_) end)
                    end)
                end
                cy=cy+72
            end
            profileScroll.CanvasSize=UDim2.new(0,0,0,cy+20)
        end

        fetchPlaylists(tostring(userId), function(ok, data)
            if isOwnProfile then playerPlaylists = ok and data or playerPlaylists end
            renderCards(ok and data or {})
        end)
    end

    -- ── Lógica de troca de abas ──────────────────────────────────
    local function switchTab(tab)
        if tab == "musicas" then
            tabMusicas.TextColor3 = isTop1 and GOLD1 or Color3.fromRGB(255,255,255); tabMusicas.Font = Enum.Font.GothamBold
            tabPlaylists.TextColor3 = isTop1 and GOLD2 or Color3.fromRGB(150,150,200); tabPlaylists.Font = Enum.Font.Gotham
            TweenService:Create(tabIndicator,TweenInfo.new(0.25,Enum.EasingStyle.Quad),{Position=UDim2.new(0,0,1,-2)}):Play()
            clearContent(); renderMusicTab()
        else
            tabPlaylists.TextColor3 = isTop1 and GOLD1 or Color3.fromRGB(255,255,255); tabPlaylists.Font = Enum.Font.GothamBold
            tabMusicas.TextColor3 = isTop1 and GOLD2 or Color3.fromRGB(150,150,200); tabMusicas.Font = Enum.Font.Gotham
            TweenService:Create(tabIndicator,TweenInfo.new(0.25,Enum.EasingStyle.Quad),{Position=UDim2.new(0.5,0,1,-2)}):Play()
            clearContent(); renderPlaylistTab()
        end
        currentTab = tab
    end

    tabMusicas.MouseButton1Click:Connect(function() switchTab("musicas") end)
    tabPlaylists.MouseButton1Click:Connect(function() switchTab("playlists") end)
    renderMusicTab()   -- aba inicial

    -- ── Animação de entrada ──────────────────────────────────────
    local guiBorder = mainFrame:FindFirstChild("BorderFrame")
    if guiBorder and isTop1 then
        guiBorder.Transparency=0
        TweenService:Create(guiBorder,TweenInfo.new(0.6,Enum.EasingStyle.Sine),{Color=GOLD1}):Play()
        spawn(function()
            while profileFrame.Parent do
                TweenService:Create(guiBorder,TweenInfo.new(1.2,Enum.EasingStyle.Sine,Enum.EasingDirection.InOut),{Color=GOLD2}):Play(); wait(1.2)
                TweenService:Create(guiBorder,TweenInfo.new(1.2,Enum.EasingStyle.Sine,Enum.EasingDirection.InOut),{Color=GOLD1}):Play(); wait(1.2)
            end
        end)
    end

    if isTop1 then
        profileFrame.Size=UDim2.new(0.6,0,0.6,0); profileFrame.Position=UDim2.new(0.2,0,0.2,0); profileFrame.BackgroundTransparency=1
        TweenService:Create(profileFrame,TweenInfo.new(0.6,Enum.EasingStyle.Back,Enum.EasingDirection.Out),{Size=UDim2.new(1,0,1,0),Position=UDim2.new(0,0,0,0),BackgroundTransparency=1}):Play()
    else
        TweenService:Create(profileFrame,TweenInfo.new(0.5,Enum.EasingStyle.Back,Enum.EasingDirection.Out),{Position=UDim2.new(0,0,0,0)}):Play()
    end
end

-- 🏗️ CRIAÇÃO DA INTERFACE PRINCIPAL (COM ABAS
-- ATUALIZAÇÃO v3.3: Função agora retorna função para resetar as abas
local function createFloatingButton()
    local floatingGui = Instance.new("ScreenGui")
    floatingGui.Name = "FloatingMusicButton"
    floatingGui.Parent = player:WaitForChild("PlayerGui")
    floatingGui.ResetOnSpawn = false
    floatingGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

    local container, rgbBorder, icon = createLogoWidget(
        floatingGui, 68, UDim2.new(0, 12, 0.5, -34), 2
    )

    -- €€ HITBOX €€
    local floatingButton = Instance.new("TextButton", container)
    floatingButton.Name = "FloatingButton"
    floatingButton.Size = UDim2.new(1, 0, 1, 0)
    floatingButton.BackgroundTransparency = 1
    floatingButton.Text = ""
    floatingButton.ZIndex = 5

    -- €€ DRAG €€
    local dragging = false
    local dragStartMouse = Vector2.new()
    local dragStartPos = UDim2.new()

    floatingButton.InputBegan:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1
        or input.UserInputType == Enum.UserInputType.Touch then
            dragging = true
            dragStartMouse = Vector2.new(input.Position.X, input.Position.Y)
            dragStartPos = container.Position
        end
    end)

    UserInputService.InputChanged:Connect(function(input)
        if not dragging then return end
        if input.UserInputType ~= Enum.UserInputType.MouseMovement
        and input.UserInputType ~= Enum.UserInputType.Touch then return end
        local delta = Vector2.new(input.Position.X, input.Position.Y) - dragStartMouse
        local screenSize = floatingGui.AbsoluteSize
        local newX = dragStartPos.X.Offset + delta.X
        local newY = dragStartPos.Y.Offset + dragStartPos.Y.Scale * screenSize.Y + delta.Y
        container.Position = UDim2.new(0, newX, 0, newY)
    end)

    UserInputService.InputEnded:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1
        or input.UserInputType == Enum.UserInputType.Touch then
            dragging = false
        end
    end)

    -- €€ PARTÍCULAS €€
    local function spawnParticle()
        local p = Instance.new("Frame")
        local sz = math.random(3, 7)
        local angle = math.random(0, 360) * math.pi / 180
        local dist = math.random(36, 48)
        local absPos = container.AbsolutePosition
        local cx = absPos.X + 34
        local cy = absPos.Y + 34
        p.Size = UDim2.new(0, sz, 0, sz)
        p.Position = UDim2.new(0, cx + math.cos(angle) * dist - sz/2, 0, cy + math.sin(angle) * dist - sz/2)
        p.BackgroundColor3 = RGB_COLORS[math.random(1, #RGB_COLORS)]
        p.BackgroundTransparency = 0.2
        p.BorderSizePixel = 0
        p.ZIndex = 1
        p.Parent = floatingGui
        Instance.new("UICorner", p).CornerRadius = UDim.new(1, 0)
        local dur = math.random(8, 16) / 10
        TweenService:Create(p, TweenInfo.new(dur, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
            Position = UDim2.new(0, p.Position.X.Offset + math.random(-20, 20), 0, p.Position.Y.Offset + math.random(-20, 20)),
            BackgroundTransparency = 1, Size = UDim2.new(0, 1, 0, 1)
        }):Play()
        task.delay(dur, function() if p and p.Parent then p:Destroy() end end)
    end

    spawn(function()
        while container.Parent do
            if not dragging then spawnParticle() end
            wait(0.6)
        end
    end)

    -- €€ HOVER €€
    floatingButton.MouseEnter:Connect(function()
        if dragging then return end
        TweenService:Create(container, TweenInfo.new(0.18, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {Size = UDim2.new(0, 76, 0, 76)}):Play()
        TweenService:Create(rgbBorder, TweenInfo.new(0.18), {Thickness = 4}):Play()
    end)
    floatingButton.MouseLeave:Connect(function()
        if dragging then return end
        TweenService:Create(container, TweenInfo.new(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {Size = UDim2.new(0, 68, 0, 68)}):Play()
        TweenService:Create(rgbBorder, TweenInfo.new(0.18), {Thickness = 3}):Play()
    end)

    -- €€ CLICK SQUEEZE €€
    floatingButton.MouseButton1Click:Connect(function()
        if dragging then return end
        TweenService:Create(container, TweenInfo.new(0.08), {Size = UDim2.new(0, 60, 0, 60)}):Play()
        task.wait(0.08)
        TweenService:Create(container, TweenInfo.new(0.15, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {Size = UDim2.new(0, 68, 0, 68)}):Play()
    end)

    -- €€ BORDA RGB FLUTUANTE EXCLUSIVA (espessa e pulsante) €€
    spawn(function()
        local colors = {
            Color3.fromRGB(255, 0, 120),
            Color3.fromRGB(255, 80, 0),
            Color3.fromRGB(255, 220, 0),
            Color3.fromRGB(0, 255, 120),
            Color3.fromRGB(0, 180, 255),
            Color3.fromRGB(120, 0, 255),
        }
        local i = 1
        while container.Parent do
            i = i % #colors + 1
            TweenService:Create(rgbBorder, TweenInfo.new(0.7, Enum.EasingStyle.Sine), {
                Color     = colors[i],
                Thickness = 4
            }):Play()
            -- pulso de tamanho sincronizado com a cor
            TweenService:Create(container, TweenInfo.new(0.35, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
                Size = UDim2.new(0, 72, 0, 72)
            }):Play()
            task.wait(0.35)
            TweenService:Create(container, TweenInfo.new(0.35, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
                Size = UDim2.new(0, 68, 0, 68)
            }):Play()
            task.wait(0.35)
        end
    end)

    return floatingGui, floatingButton, rgbBorder
end

-- ===============================
-- ✨ EFEITOS VISUAIS
-- ===============================
local TweenService = game:GetService("TweenService")

local function applyHoverPro(frame, isFirst)
	local scale = Instance.new("UIScale")
	scale.Scale = 1
	scale.Parent = frame

	local enter = TweenService:Create(
		scale,
		TweenInfo.new(0.15, Enum.EasingStyle.Back, Enum.EasingDirection.Out),
		{ Scale = isFirst and 1.05 or 1.02 }
	)

	local leave = TweenService:Create(
		scale,
		TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
		{ Scale = 1 }
	)

	frame.MouseEnter:Connect(function()
		enter:Play()
	end)

	frame.MouseLeave:Connect(function()
		leave:Play()
	end)
end

local function addGradient(frame, c1, c2)
	local g = Instance.new("UIGradient")
	g.Color = ColorSequence.new{
		ColorSequenceKeypoint.new(0, c1),
		ColorSequenceKeypoint.new(1, c2)
	}
	g.Rotation = 0
	g.Parent = frame
	return g
end

local function animateGradient(gradient)
	if not gradient then return end
	TweenService:Create(
		gradient,
		TweenInfo.new(4, Enum.EasingStyle.Linear, Enum.EasingDirection.InOut, -1),
		{ Rotation = 360 }
	):Play()
end

local function addGlow(frame, color)
	local stroke = Instance.new("UIStroke")
	stroke.Color = color
	stroke.Thickness = 3
	stroke.Transparency = 0.25
	stroke.Parent = frame

	TweenService:Create(
		stroke,
		TweenInfo.new(1.2, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true),
		{ Transparency = 0.05 }
	):Play()
end

local function addSparkles(frame)
	for i = 1, 6 do
		local dot = Instance.new("Frame")
		dot.Size = UDim2.new(0, 4, 0, 4)
		dot.Position = UDim2.fromScale(math.random(), math.random())
		dot.BackgroundColor3 = Color3.fromRGB(255, 230, 150)
		dot.BackgroundTransparency = 0.2
		dot.ZIndex = 5
		dot.Parent = frame
		Instance.new("UICorner", dot).CornerRadius = UDim.new(1,0)

		TweenService:Create(
			dot,
			TweenInfo.new(1 + math.random(), Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true),
			{ BackgroundTransparency = 1 }
		):Play()
	end
end

-- ===============================
-- 🏆 FUNÇÃO PRINCIPAL
-- ===============================

-- onComplete(): chamado quando todo o cálculo terminar (usado pela splash para saber quando fechar)
-- onProgress(pct, msg): atualiza progresso externo por etapa das buscas paralelas
function updateLeaderboard(leaderboardScroll, mainFrame, onComplete, onProgress)
	if not leaderboardScroll then
		if onComplete then onComplete() end
		return
	end

	-- Limpar lista
	for _, child in ipairs(leaderboardScroll:GetChildren()) do
		if child:IsA("Frame") or child:IsA("TextLabel") then child:Destroy() end
	end

	-- Sem dados
	if not allMusicData or #allMusicData == 0 then
		local msg = Instance.new("TextLabel")
		msg.Size = UDim2.new(1, 0, 0, 100)
		msg.BackgroundTransparency = 1
		msg.Text = "Sem músicas carregadas."
		msg.TextColor3 = Color3.fromRGB(150,150,150)
		msg.Font = Enum.Font.Gotham
		msg.TextSize = 16
		msg.Parent = leaderboardScroll
		if onComplete then onComplete() end
		return
	end

	-- Painel flutuante de carregamento — só exibe se NÃO vier da splash (onProgress == nil)
	local _closeRankLoad
	if not onProgress then
		makeFloatingPanel(mainFrame, {
			zBase        = 55,
			panelSize    = UDim2.new(0, 220, 0, 140),
			panelPos     = UDim2.new(0.5, -110, 0.5, -70),
			cornerRadius = 18,
			overlayClose = false,
			gradient     = true,
			rgbSpeed     = 1,
		}, function(panel, closeFn)
			_closeRankLoad = closeFn
			local ico = Instance.new("TextLabel", panel)
			ico.Size = UDim2.new(1,0,0,40); ico.Position = UDim2.new(0,0,0,12)
			ico.BackgroundTransparency=1; ico.Text="🏆"; ico.TextSize=32
			ico.Font=Enum.Font.GothamBold; ico.ZIndex=57; ico.TextXAlignment=Enum.TextXAlignment.Center
			TweenService:Create(ico, TweenInfo.new(0.9,Enum.EasingStyle.Sine,Enum.EasingDirection.InOut,-1,true), {TextSize=38}):Play()
			local lbl = Instance.new("TextLabel", panel)
			lbl.Size=UDim2.new(1,-16,0,24); lbl.Position=UDim2.new(0,8,0,60)
			lbl.BackgroundTransparency=1; lbl.Text="Calculando fama..."
			lbl.TextColor3=Color3.fromRGB(220,220,255); lbl.Font=Enum.Font.GothamBold
			lbl.TextSize=14; lbl.ZIndex=57; lbl.TextXAlignment=Enum.TextXAlignment.Center
			animRGB(lbl, "TextColor3", 1.2)
			local barBg = Instance.new("Frame", panel)
			barBg.Size=UDim2.new(1,-24,0,5); barBg.Position=UDim2.new(0,12,0,94)
			barBg.BackgroundColor3=Color3.fromRGB(30,30,45); barBg.BorderSizePixel=0; barBg.ZIndex=57
			barBg.ClipsDescendants=true; Instance.new("UICorner",barBg).CornerRadius=UDim.new(1,0)
			local barFill=Instance.new("Frame",barBg)
			barFill.Size=UDim2.new(0.3,0,1,0); barFill.Position=UDim2.new(-0.3,0,0,0)
			barFill.BorderSizePixel=0; barFill.ZIndex=58; barFill.BackgroundColor3=RGB_COLORS[1]
			Instance.new("UICorner",barFill).CornerRadius=UDim.new(1,0)
			animRGB(barFill,"BackgroundColor3",1)
			task.spawn(function()
				while barFill.Parent do
					TweenService:Create(barFill,TweenInfo.new(0.85,Enum.EasingStyle.Quad,Enum.EasingDirection.InOut),{Position=UDim2.new(1,0,0,0)}):Play()
					wait(0.85); barFill.Position=UDim2.new(-0.3,0,0,0)
				end
			end)
		end)
	end

	-- ── Agrupar músicas por usuário ──────────────────────────────
	local userMap = {}
	for _, song in ipairs(allMusicData) do
		local uid = tostring(song.UserId)
		if not userMap[uid] then
			userMap[uid] = {
				UserId      = song.UserId,
				DisplayName = song.DisplayName,
				PlayerName  = song.PlayerName,
				Foto        = song.Foto,
				musicCount  = 0,
				musicIds    = {},
				totalLikes  = 0,
				followers   = 0,
				fameScore   = 0,
			}
		end
		userMap[uid].musicCount += 1
		table.insert(userMap[uid].musicIds, tostring(song.ID_Musica))
	end

	local userList = {}
	for _, ud in pairs(userMap) do table.insert(userList, ud) end

	local total = #userList
	if total == 0 then
		if onComplete then onComplete() end
		return
	end

	-- ── Renderizar ranking após todos os dados chegarem ──────────
	local function onAllDone()
		-- Fecha o painel de carregamento (modo manual)
		if _closeRankLoad then _closeRankLoad() end

		-- ┌────────────────────────────────────────────────────────┐
		-- │  FÓRMULA DE FAMA (pesos balanceados)                   │
		-- │  seguidores × 3  +  likes totais × 2  +  músicas × 1  │
		-- │  • Seguidores: maior peso — popularidade real           │
		-- │  • Likes: peso médio — engajamento com o conteúdo      │
		-- │  • Músicas: menor peso — contribuição, não spam         │
		-- └────────────────────────────────────────────────────────┘
		for _, ud in ipairs(userList) do
			ud.fameScore = (ud.followers * 3) + (ud.totalLikes * 2) + (ud.musicCount * 1)
		end

		table.sort(userList, function(a, b) return a.fameScore > b.fameScore end)

		-- Salva o TOP 1 no cache global (usado pelo createProfileView)
		_top1FameUserId  = userList[1] and tostring(userList[1].UserId) or nil
		_cache.top1UserId = _top1FameUserId

		-- Render top 10
		local yPos = 12
		for i = 1, math.min(10, #userList) do
			local userData = userList[i]
			local isFirst  = (i == 1)
			local cardHeight = isFirst and 100 or 72

			local rankCard = Instance.new("Frame")
			rankCard.Size = UDim2.new(1, -24, 0, cardHeight)
			rankCard.Position = UDim2.new(0, 12, 0, yPos + 20)
			rankCard.BackgroundColor3 = Color3.fromRGB(22,22,28)
			rankCard.BorderSizePixel = 0
			rankCard.BackgroundTransparency = 1
			rankCard.Parent = leaderboardScroll
			Instance.new("UICorner", rankCard).CornerRadius = UDim.new(0,14)

			if isFirst then
				local grad = addGradient(rankCard, Color3.fromRGB(255,215,0), Color3.fromRGB(120,90,10))
				animateGradient(grad)
				addGlow(rankCard, Color3.fromRGB(255,215,0))
				addSparkles(rankCard)
			end

			TweenService:Create(
				rankCard,
				TweenInfo.new(isFirst and 0.5 or 0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
				{ Position = UDim2.new(0,12,0,yPos), BackgroundTransparency = 0 }
			):Play()

			applyHoverPro(rankCard, isFirst)

			-- Rank texto
			local rankTxt = Instance.new("TextLabel", rankCard)
			rankTxt.Size = UDim2.new(0,45,1,0)
			rankTxt.BackgroundTransparency = 1
			rankTxt.Text = isFirst and "👑" or "#"..i
			rankTxt.Font = Enum.Font.GothamBold
			rankTxt.TextSize = isFirst and 30 or 20
			rankTxt.TextColor3 = Color3.new(1,1,1)
			if isFirst then
				TweenService:Create(rankTxt,
					TweenInfo.new(0.8, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true),
					{ Rotation = 6 }
				):Play()
			end

			-- Avatar
			local avatar = Instance.new("ImageLabel", rankCard)
			avatar.Size = UDim2.new(0,48,0,48)
			avatar.Position = UDim2.new(0,50,0.5,-24)
			avatar.BackgroundTransparency = 1
			avatar.Image = normalizeImageUrl(userData.Foto, userData.UserId)
			Instance.new("UICorner", avatar).CornerRadius = UDim.new(1,0)

			-- Nome
			local nameLabel = Instance.new("TextLabel", rankCard)
			nameLabel.Size = UDim2.new(1,-200,0,22)
			nameLabel.Position = UDim2.new(0,110,0.5,-16)
			nameLabel.BackgroundTransparency = 1
			nameLabel.TextXAlignment = Enum.TextXAlignment.Left
			nameLabel.Font = Enum.Font.GothamBold
			nameLabel.TextSize = 15
			nameLabel.TextColor3 = Color3.new(1,1,1)
			nameLabel.Text = userData.DisplayName or userData.PlayerName or "Usuário"
			nameLabel.TextTruncate = Enum.TextTruncate.AtEnd

			-- Sub-info: ❤ likes  👥 seguidores  🎵 músicas
			local subLabel = Instance.new("TextLabel", rankCard)
			subLabel.Size = UDim2.new(1,-200,0,14)
			subLabel.Position = UDim2.new(0,110,0.5,8)
			subLabel.BackgroundTransparency = 1
			subLabel.TextXAlignment = Enum.TextXAlignment.Left
			subLabel.Font = Enum.Font.Gotham
			subLabel.TextSize = 11
			subLabel.TextColor3 = Color3.fromRGB(160,160,190)
			subLabel.Text = string.format(
				"❤ %s   👥 %s   🎵 %d",
				formatCount(userData.totalLikes),
				formatCount(userData.followers),
				userData.musicCount
			)

			-- Badge de fama
			local badge = Instance.new("TextLabel", rankCard)
			badge.Size = UDim2.new(0,110,0,34)
			badge.Position = UDim2.new(1,-120,0.5,-17)
			badge.Font = Enum.Font.GothamBold
			badge.TextSize = 13
			badge.BorderSizePixel = 0
			badge.BackgroundTransparency = 0
			if isFirst then
				badge.Text = "🏆 "..formatCount(userData.fameScore)
				badge.TextColor3 = Color3.fromRGB(255,220,120)
				badge.BackgroundColor3 = Color3.fromRGB(60,45,10)
			else
				badge.Text = "⭐ "..formatCount(userData.fameScore)
				badge.TextColor3 = Color3.fromRGB(0,255,160)
				badge.BackgroundColor3 = Color3.fromRGB(15,15,20)
			end
			Instance.new("UICorner", badge).CornerRadius = UDim.new(0,10)

			-- Botão invisível (abrir perfil)
			local btn = Instance.new("TextButton", rankCard)
			btn.Size = UDim2.new(1,0,1,0)
			btn.BackgroundTransparency = 1
			btn.Text = ""
			btn.MouseButton1Click:Connect(function()
				if createProfileView then createProfileView(mainFrame, userData) end
			end)

			yPos += cardHeight + 10
		end

		leaderboardScroll.CanvasSize = UDim2.new(0,0,0,yPos + 12)

		-- Notifica quem chamou que o cálculo completo terminou (ex: splash screen)
		if onComplete then onComplete() end
	end

	-- ════════════════════════════════════════════════════════════
	-- 2 requests globais em vez de N×2 requests por usuário
	-- ─────────────────────────────────────────────────────────
	-- Request A: todos os likes de todas as músicas de uma vez
	--   GET /likes?music_id=in.(id1,id2,...)&select=music_id
	--   → agrupa em Lua: likesPerMusic[music_id] = count
	--   → soma por usuário via userMap[uid].musicIds
	--
	-- Request B: todos os seguidores de todos os players de uma vez
	--   GET /follows?following_id=in.(uid1,uid2,...)&select=following_id
	--   → conta em Lua: followersPerUser[following_id] = count
	-- ════════════════════════════════════════════════════════════

	-- Coleta todos os IDs de músicas e todos os UserIds
	local allMusicIds = {}
	local allUserIds  = {}
	for _, ud in ipairs(userList) do
		for _, mid in ipairs(ud.musicIds) do
			table.insert(allMusicIds, mid)
		end
		table.insert(allUserIds, tostring(ud.UserId))
	end

	local likesReady   = false
	local followsReady = false
	local likesPerMusic = {}     -- [music_id_string] = count
	local followersPerUser = {}  -- [user_id_string]  = count

	local function tryFinish()
		if not (likesReady and followsReady) then return end

		-- Distribui os dados nos userList
		for _, ud in ipairs(userList) do
			local total_likes = 0
			for _, mid in ipairs(ud.musicIds) do
				total_likes += (likesPerMusic[mid] or 0)
			end
			ud.totalLikes = total_likes
			ud.followers  = followersPerUser[tostring(ud.UserId)] or 0
		end

		if onProgress then onProgress(99, "Calculando pontuações...") end
		onAllDone()
	end

	-- Request A — likes globais
	task.spawn(function()
		if onProgress then onProgress(91, "Buscando likes...") end
		if #allMusicIds > 0 then
			local idsParam = table.concat(allMusicIds, ",")
			local ok, res = pcall(function()
				return request({
					Url     = SUPABASE_URL.."/rest/v1/likes?music_id=in.("..idsParam..")&select=music_id",
					Method  = "GET",
					Headers = sbHeaders()
				})
			end)
			if ok and res and res.Body then
				local pok, rows = pcall(function() return HttpService:JSONDecode(res.Body) end)
				if pok and type(rows) == "table" then
					for _, row in ipairs(rows) do
						local mid = tostring(row.music_id)
						likesPerMusic[mid] = (likesPerMusic[mid] or 0) + 1
					end
				end
			end
		end
		likesReady = true
		tryFinish()
	end)

	-- Request B — seguidores globais
	task.spawn(function()
		if onProgress then onProgress(93, "Buscando seguidores...") end
		if #allUserIds > 0 then
			local uidsParam = table.concat(allUserIds, ",")
			local ok, res = pcall(function()
				return request({
					Url     = SUPABASE_URL.."/rest/v1/follows?following_id=in.("..uidsParam..")&select=following_id",
					Method  = "GET",
					Headers = sbHeaders()
				})
			end)
			if ok and res and res.Body then
				local pok, rows = pcall(function() return HttpService:JSONDecode(res.Body) end)
				if pok and type(rows) == "table" then
					for _, row in ipairs(rows) do
						local uid = tostring(row.following_id)
						followersPerUser[uid] = (followersPerUser[uid] or 0) + 1
					end
				end
			end
		end
		followsReady = true
		tryFinish()
	end)
end


-- ── Exportar ──────────────────────────────────────────────────
TMI.createProfileView  = createProfileView
TMI.updateLeaderboard  = updateLeaderboard
TMI.createFloatingButton = createFloatingButton

print("[TMI] profile.lua carregado ✓")
