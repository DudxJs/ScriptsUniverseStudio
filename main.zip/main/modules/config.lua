-- ══════════════════════════════════════════════════════════════
-- 📦 config.lua — Constantes, IDs de ícones, variáveis de estado
-- Carregado PRIMEIRO. Todos os módulos lêem de _G.TMI
-- ══════════════════════════════════════════════════════════════

_G.TMI = _G.TMI or {}
local TMI = _G.TMI

-- ── Serviços ──────────────────────────────────────────────────
TMI.player           = game:GetService("Players").LocalPlayer
TMI.HttpService      = game:GetService("HttpService")
TMI.TweenService     = game:GetService("TweenService")
TMI.UserInputService = game:GetService("UserInputService")
TMI.RunService       = game:GetService("RunService")
TMI.request          = (http_request or request or http_get or syn and syn.request)

if not TMI.request then
    warn("❌ Seu executor não suporta http_request.")
    return
end

-- ── Ícones ────────────────────────────────────────────────────
TMI.ICONS = {
    PLAY          = "rbxassetid://8517323790",
    PAUSE         = "rbxassetid://14219414360",
    LOADING       = "rbxassetid://15802670993",
    CLOSE         = "rbxassetid://10152135063",
    BACK          = "rbxassetid://11568974988",
    LISTEN        = "rbxassetid://126358805627316",
    MUSIC_BACK    = "rbxassetid://12662712394",
    MUSIC_RESTART = "rbxassetid://73040575692909",
    MUSIC_NOTE    = "rbxassetid://99073204245716",
    TAB_HOME      = "rbxassetid://77908533037176",
    TAB_MUSICAS   = "rbxassetid://92870725219407",
    TAB_PUBLICAR  = "rbxassetid://78689563976440",
    TAB_TOP10     = "rbxassetid://8587689304",
    LIKE_OFF      = "rbxassetid://18449541296",
    LIKE_ON       = "rbxassetid://18473993328",
    EDIT          = "rbxassetid://15911231575",
    COPY          = "rbxassetid://90434151822042",
    OK            = "rbxassetid://17829956110",
    DELETE        = "rbxassetid://93711689312435",
    WARN          = "rbxassetid://71503984286896",
    ADD           = "rbxassetid://133565608904662",
    MORE          = "rbxassetid://15567841177",
    LOGO          = "rbxassetid://116956778802642",
    TITLE_IMG     = "rbxassetid://131495773923485",
    LINK          = "rbxassetid://90311471693516",
    VERIFY        = "rbxassetid://110485530826693",
    FILTER        = "rbxassetid://7964618035",
    SEARCH_TYPE   = "rbxassetid://112780490255100",
    IC_PLAYER     = "rbxassetid://17132521951",
    IC_DATE       = "rbxassetid://97651580914952",
    IC_CATEGORY   = "rbxassetid://78388764182737",
    IC_ID         = "rbxassetid://71240916317731",
}

-- ── Cores RGB animadas ─────────────────────────────────────────
TMI.RGB_COLORS = {
    Color3.fromRGB(255, 0,   128),
    Color3.fromRGB(0,   255, 128),
    Color3.fromRGB(128, 0,   255),
    Color3.fromRGB(255, 128, 0),
    Color3.fromRGB(0,   128, 255),
}

-- ── Supabase ──────────────────────────────────────────────────
TMI.SUPABASE_URL = "https://hakzrnzsbcgnaauigbcg.supabase.co"
TMI.SUPABASE_KEY = "sb_publishable_0L3e3lgthzjJvac2wKNnwQ_Z1_Hi_2L"

-- ── Key System ────────────────────────────────────────────────
TMI.APPS_SCRIPT_URL    = "https://script.google.com/macros/s/AKfycbxjrDVksvmGwdf2cZ5o07HnyK9xtVr1dPbOxtzcTJ-2vncBNzznVSri_ZbvWj5x_kkn/exec"
TMI.API_SECRET         = "zXyWvUtSrQpOnMlKjIhGfEdCbA12345678909876543210qWeRt"
TMI.SITE_URL           = "https://keysystem-eus.netlify.app/"
TMI.SCRIPT_NAME        = "publish_music"
TMI.EDIT_SCRIPT_NAME   = "edit_music"
TMI.PLAYLIST_SCRIPT_NAME = "playlist_create"

-- ── Categorias ────────────────────────────────────────────────
TMI.CATEGORIES_LIST = {"Funk","Phonk","Hip Hop","Electronic","Rock","Pop","Classical","Jazz","Other"}

-- ── Cache global ──────────────────────────────────────────────
TMI._cache = {
    musicData    = {},
    likesMap     = {},
    myLikes      = {},
    followersMap = {},
    myFollowing  = {},
    leaderboard  = nil,
    top1UserId   = nil,
}
TMI._dirty = {
    musicList   = true,
    leaderboard = true,
}

-- ── Estado de filtros / lista ─────────────────────────────────
TMI.currentSearchType    = "Nome"
TMI.currentStartIndex    = 1
TMI.itemsPerBatch        = 200
TMI.currentFilterText    = ""
TMI.currentSortOrder     = "newest"   -- "newest" | "oldest"
TMI.currentSortMode      = "date"     -- "date"   | "liked"
TMI.selectedCategories   = {}

-- ── Estado de playlists ───────────────────────────────────────
TMI.playerPlaylists       = {}
TMI.playlistKeyUnlocked   = false

-- ── Misc ──────────────────────────────────────────────────────
TMI.allMusicData          = TMI._cache.musicData   -- alias legado
TMI.isFetching            = false
TMI._top1FameUserId       = nil

print("[TMI] config.lua carregado ✓")
