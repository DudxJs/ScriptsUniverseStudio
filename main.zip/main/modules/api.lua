-- ══════════════════════════════════════════════════════════════
-- 📡 api.lua — Supabase, Key System, Cache, Playlist API
-- Depende de: config.lua, core.lua
-- ══════════════════════════════════════════════════════════════

local TMI         = _G.TMI
local player      = TMI.player
local HttpService = TMI.HttpService
local request     = TMI.request
local _cache      = TMI._cache
local _dirty      = TMI._dirty

-- ── Atalhos de config ─────────────────────────────────────────
local SUPABASE_URL       = TMI.SUPABASE_URL
local SUPABASE_KEY       = TMI.SUPABASE_KEY
local APPS_SCRIPT_URL    = TMI.APPS_SCRIPT_URL
local API_SECRET         = TMI.API_SECRET
local SITE_URL           = TMI.SITE_URL
local SCRIPT_NAME        = TMI.SCRIPT_NAME

-- ══════════════════════════════════════════════════════════════
-- 🌐 SUPABASE HELPERS
-- ══════════════════════════════════════════════════════════════
local function sbHeaders(extras)
    local h = {
        ["apikey"]        = SUPABASE_KEY,
        ["Authorization"] = "Bearer " .. SUPABASE_KEY,
        ["Content-Type"]  = "application/json",
        ["Prefer"]        = "return=representation",
        ["x-player-id"]   = tostring(player.UserId),
    }
    if extras then for k, v in pairs(extras) do h[k] = v end end
    return h
end

local function sbPatch(tbl, filter, body)
    local url = SUPABASE_URL .. "/rest/v1/" .. tbl .. "?" .. filter
    local res = request({
        Url     = url,
        Method  = "PATCH",
        Headers = sbHeaders(),
        Body    = HttpService:JSONEncode(body),
    })
    return res
end

-- ══════════════════════════════════════════════════════════════
-- 👍 LIKES
-- ══════════════════════════════════════════════════════════════
local function fetchLikeCount(musicId, callback)
    callback(_cache.likesMap[tostring(musicId)] or 0)
end

local function checkPlayerLiked(musicId, callback)
    callback(_cache.myLikes[tostring(musicId)] == true)
end

local function giveLike(musicId, callback)
    local mid = tostring(musicId)
    _cache.likesMap[mid] = (_cache.likesMap[mid] or 0) + 1
    _cache.myLikes[mid]  = true
    _dirty.leaderboard   = true
    task.spawn(function()
        local ok, res = pcall(function()
            return request({ Url = SUPABASE_URL.."/rest/v1/likes", Method = "POST",
                Headers = sbHeaders(),
                Body = HttpService:JSONEncode({ user_id = tostring(player.UserId), music_id = mid }) })
        end)
        local st = ok and res and tonumber(res.StatusCode) or 0
        local success = (st == 201 or st == 200)
        if not success then
            _cache.likesMap[mid] = math.max(0, (_cache.likesMap[mid] or 1) - 1)
            _cache.myLikes[mid]  = nil
        end
        if callback then callback(success) end
    end)
end

local function removeLike(musicId, callback)
    local mid = tostring(musicId)
    _cache.likesMap[mid] = math.max(0, (_cache.likesMap[mid] or 1) - 1)
    _cache.myLikes[mid]  = nil
    _dirty.leaderboard   = true
    task.spawn(function()
        local ok, res = pcall(function()
            return request({ Url = SUPABASE_URL.."/rest/v1/likes?user_id=eq."..tostring(player.UserId).."&music_id=eq."..mid,
                Method = "DELETE", Headers = sbHeaders() })
        end)
        local st = ok and res and tonumber(res.StatusCode) or 0
        local success = (st == 200 or st == 204)
        if not success then
            _cache.likesMap[mid] = (_cache.likesMap[mid] or 0) + 1
            _cache.myLikes[mid]  = true
        end
        if callback then callback(success) end
    end)
end

-- ══════════════════════════════════════════════════════════════
-- 👥 FOLLOWS
-- ══════════════════════════════════════════════════════════════
local function fetchFollowCount(userId, callback)
    callback(_cache.followersMap[tostring(userId)] or 0)
end

local function fetchFollowingCount(userId, callback)
    task.spawn(function()
        if tostring(userId) == tostring(player.UserId) then
            local cnt = 0
            for _ in pairs(_cache.myFollowing) do cnt += 1 end
            callback(cnt)
        else
            local ok, res = pcall(function()
                return request({ Url = SUPABASE_URL.."/rest/v1/follows?follower_id=eq."..tostring(userId).."&select=id",
                    Method = "GET", Headers = sbHeaders() })
            end)
            local count = 0
            if ok and res and res.Body then
                local pok, rows = pcall(function() return HttpService:JSONDecode(res.Body) end)
                count = (pok and type(rows) == "table") and #rows or 0
            end
            callback(count)
        end
    end)
end

local function checkIsFollowing(targetUserId, callback)
    task.spawn(function()
        callback(_cache.myFollowing[tostring(targetUserId)] == true)
    end)
end

local function followUser(targetUserId, callback)
    local uid = tostring(targetUserId)
    _cache.myFollowing[uid]  = true
    _cache.followersMap[uid] = (_cache.followersMap[uid] or 0) + 1
    _dirty.leaderboard       = true
    task.spawn(function()
        local ok, res = pcall(function()
            return request({ Url = SUPABASE_URL.."/rest/v1/follows", Method = "POST",
                Headers = sbHeaders(),
                Body = HttpService:JSONEncode({ follower_id = tostring(player.UserId), following_id = uid }) })
        end)
        local st = ok and res and tonumber(res.StatusCode) or 0
        local success = (st == 201 or st == 200)
        if not success then
            _cache.myFollowing[uid]  = nil
            _cache.followersMap[uid] = math.max(0, (_cache.followersMap[uid] or 1) - 1)
        end
        if callback then callback(success) end
    end)
end

local function unfollowUser(targetUserId, callback)
    local uid = tostring(targetUserId)
    _cache.myFollowing[uid]  = nil
    _cache.followersMap[uid] = math.max(0, (_cache.followersMap[uid] or 1) - 1)
    _dirty.leaderboard       = true
    task.spawn(function()
        local ok, res = pcall(function()
            return request({ Url = SUPABASE_URL.."/rest/v1/follows?follower_id=eq."..tostring(player.UserId).."&following_id=eq."..uid,
                Method = "DELETE", Headers = sbHeaders() })
        end)
        local st = ok and res and tonumber(res.StatusCode) or 0
        local success = (st == 200 or st == 204)
        if not success then
            _cache.myFollowing[uid]  = true
            _cache.followersMap[uid] = (_cache.followersMap[uid] or 0) + 1
        end
        if callback then callback(success) end
    end)
end

-- ══════════════════════════════════════════════════════════════
-- 🔐 KEY SYSTEM
-- ══════════════════════════════════════════════════════════════
local function getHash()
    local success, ip = pcall(function()
        return game:HttpGet("https://v4.ident.me"):gsub("%s+", "")
    end)
    if not success then return "ERROR_HASH_GEN" end
    local chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    local res = ((ip:gsub('.', function(x)
        local r, b = '', x:byte()
        for i = 8, 1, -1 do r = r .. (b % 2^i - b % 2^(i-1) > 0 and '1' or '0') end
        return r
    end) .. '0000'):gsub('%d%d%d?%d?%d?%d?', function(x)
        if #x < 6 then return '' end
        local c = 0
        for i = 1, 6 do c = c + (x:sub(i,i) == '1' and 2^(6-i) or 0) end
        return chars:sub(c+1, c+1)
    end) .. ({ '', '==', '=' })[#ip % 3 + 1])
    return res:gsub("=", "")
end

local userHash = getHash()
TMI.userHash = userHash

local function callApi(action, params)
    local url = APPS_SCRIPT_URL .. "?action=" .. action .. "&secret=" .. API_SECRET
    for k, v in pairs(params or {}) do
        url = url .. "&" .. k .. "=" .. HttpService:UrlEncode(tostring(v))
    end
    local ok, response = pcall(function() return game:HttpGet(url) end)
    if not ok then warn("Erro ao chamar API: "..tostring(response)); return nil end
    local jok, data = pcall(function() return HttpService:JSONDecode(response) end)
    if not jok then warn("Resposta inválida da API: "..tostring(response)); return nil end
    if data.error then warn("API retornou erro: "..(data.msg or "desconhecido")); return nil end
    return data
end

local function generateAccessLink(scriptName)
    scriptName = scriptName or SCRIPT_NAME
    local data = callApi("getAccessInfo", { type = scriptName, ipHash = userHash })
    if not data then warn("Falha ao obter informações de acesso"); return false end
    if data.hasValidKey and data.existingToken and data.existingToken ~= "" then
        local link = SITE_URL.."?access="..data.existingToken.."&type="..scriptName
        if setclipboard then setclipboard(link) end; return true
    end
    if data.hasValidToken and data.token and data.token ~= "" then
        local link = SITE_URL.."?access="..data.token.."&type="..scriptName
        if setclipboard then setclipboard(link) end; return true
    end
    local newData = callApi("generateNewToken", { type = scriptName, ipHash = userHash })
    if not newData or not newData.token then warn("Falha ao gerar novo token"); return false end
    local link = SITE_URL.."?access="..newData.token.."&type="..scriptName
    if setclipboard then setclipboard(link) end
    return true
end

local function validateKey(inputKey, scriptName)
    scriptName = scriptName or SCRIPT_NAME
    inputKey = inputKey:gsub("%s+", "")
    local result = callApi("validateKey", { type = scriptName, ipHash = userHash, key = inputKey })
    if not result then return false, "Erro ao conectar com o sistema de validação." end
    if result.valid then return true, "Sucesso! Key validada."
    else return false, result.message or "Key inválida ou expirada." end
end

-- ══════════════════════════════════════════════════════════════
-- 🔄 CACHE — carga completa (splash + background refresh)
-- ══════════════════════════════════════════════════════════════
local function loadFullCache(onProgress, onDone)
    local function rep(p, m) if onProgress then onProgress(p, m) end end
    local results = {}
    local pending = 5

    local function checkDone()
        pending -= 1
        if pending > 0 then return end
        if type(results.musics) == "table" then
            _cache.musicData = results.musics
            TMI.allMusicData = _cache.musicData
            _dirty.musicList = false
        end
        _cache.likesMap = {}
        if type(results.allLikes) == "table" then
            for _, row in ipairs(results.allLikes) do
                local mid = tostring(row.music_id)
                _cache.likesMap[mid] = (_cache.likesMap[mid] or 0) + 1
            end
        end
        _cache.myLikes = {}
        if type(results.myLikes) == "table" then
            for _, row in ipairs(results.myLikes) do _cache.myLikes[tostring(row.music_id)] = true end
        end
        _cache.followersMap = {}
        if type(results.allFollows) == "table" then
            for _, row in ipairs(results.allFollows) do
                local uid = tostring(row.following_id)
                _cache.followersMap[uid] = (_cache.followersMap[uid] or 0) + 1
            end
        end
        _cache.myFollowing = {}
        if type(results.myFollowing) == "table" then
            for _, row in ipairs(results.myFollowing) do _cache.myFollowing[tostring(row.following_id)] = true end
        end
        _dirty.leaderboard = true
        if onDone then onDone(true) end
    end

    local function fetch(key, url, pct, msg)
        task.spawn(function()
            rep(pct, msg)
            local ok, res = pcall(function()
                return request({ Url = SUPABASE_URL..url, Method = "GET", Headers = sbHeaders() })
            end)
            if ok and res and res.Body then
                local pok, data = pcall(function() return HttpService:JSONDecode(res.Body) end)
                results[key] = (pok and type(data) == "table") and data or {}
            else results[key] = {} end
            checkDone()
        end)
    end

    fetch("musics",      "/rest/v1/musics?select=*&order=Data.desc",                                          10, "Carregando músicas...")
    fetch("allLikes",    "/rest/v1/likes?select=music_id",                                                    30, "Carregando likes...")
    fetch("myLikes",     "/rest/v1/likes?user_id=eq."..tostring(player.UserId).."&select=music_id",           50, "Verificando suas curtidas...")
    fetch("allFollows",  "/rest/v1/follows?select=following_id",                                              65, "Carregando seguidores...")
    fetch("myFollowing", "/rest/v1/follows?follower_id=eq."..tostring(player.UserId).."&select=following_id", 80, "Verificando quem você segue...")
end

local function fetchAllMusic(callback)
    loadFullCache(nil, function(ok) callback(ok, _cache.musicData) end)
end

-- ══════════════════════════════════════════════════════════════
-- 📂 PLAYLIST API
-- ══════════════════════════════════════════════════════════════
local function fetchPlaylists(userId, callback)
    task.spawn(function()
        local ok, res = pcall(function()
            return request({ Url = SUPABASE_URL.."/rest/v1/playlists?OwnerId=eq."..tostring(userId).."&select=*&order=created_at.asc",
                Method = "GET", Headers = sbHeaders() })
        end)
        if ok and res and res.Body then
            local pok, data = pcall(function() return HttpService:JSONDecode(res.Body) end)
            callback(pok and type(data) == "table", pok and data or {})
        else callback(false, {}) end
    end)
end

local function createPlaylistAPI(name, imageUrl, callback)
    task.spawn(function()
        local newId = "PL_"..tostring(player.UserId).."_"..tostring(os.time())
        local body = HttpService:JSONEncode({
            PlaylistId = newId, PlaylistName = name,
            OwnerId = tostring(player.UserId), OwnerName = player.Name,
            ImageUrl = imageUrl or "", Songs = {},
        })
        local ok, res = pcall(function()
            return request({ Url = SUPABASE_URL.."/rest/v1/playlists", Method = "POST", Headers = sbHeaders(), Body = body })
        end)
        if ok and res then
            local st = tonumber(res.StatusCode) or 0
            if st == 201 or st == 200 then callback(true, newId)
            else callback(false, tostring(res.Body or "Erro ao criar")) end
        else callback(false, "Falha de conexão") end
    end)
end

local function addSongToPlaylistAPI(playlistId, songId, callback)
    task.spawn(function()
        local ok1, res1 = pcall(function()
            return request({ Url = SUPABASE_URL.."/rest/v1/playlists?PlaylistId=eq."..tostring(playlistId).."&select=Songs",
                Method = "GET", Headers = sbHeaders() })
        end)
        if not (ok1 and res1 and res1.Body) then callback(false, "Falha de conexão"); return end
        local pok, rows = pcall(function() return HttpService:JSONDecode(res1.Body) end)
        if not pok or type(rows) ~= "table" or #rows == 0 then callback(false, "Playlist não encontrada"); return end
        local songs = rows[1].Songs or {}
        for _, s in ipairs(songs) do
            if tostring(s) == tostring(songId) then callback(false, "já está na playlist"); return end
        end
        table.insert(songs, tostring(songId))
        local ok2, res2 = pcall(function()
            return sbPatch("playlists", "PlaylistId=eq."..tostring(playlistId), { Songs = songs })
        end)
        if ok2 and res2 then
            local st = tonumber(res2.StatusCode) or 0
            callback(st == 200 or st == 204, "Sucesso")
        else callback(false, "Falha de conexão") end
    end)
end

local function removeSongFromPlaylistAPI(playlistId, songId, callback)
    task.spawn(function()
        local ok1, res1 = pcall(function()
            return request({ Url = SUPABASE_URL.."/rest/v1/playlists?PlaylistId=eq."..tostring(playlistId).."&select=Songs",
                Method = "GET", Headers = sbHeaders() })
        end)
        if not (ok1 and res1 and res1.Body) then callback(false, "Falha de conexão"); return end
        local pok, rows = pcall(function() return HttpService:JSONDecode(res1.Body) end)
        if not pok or type(rows) ~= "table" or #rows == 0 then callback(false, "Playlist não encontrada"); return end
        local songs, newSongs = rows[1].Songs or {}, {}
        for _, s in ipairs(songs) do
            if tostring(s) ~= tostring(songId) then table.insert(newSongs, tostring(s)) end
        end
        local ok2, res2 = pcall(function()
            return sbPatch("playlists", "PlaylistId=eq."..tostring(playlistId), { Songs = newSongs })
        end)
        local st = ok2 and res2 and tonumber(res2.StatusCode) or 0
        callback(st == 200 or st == 204, "Sucesso")
    end)
end

local function deletePlaylistAPI(playlistId, callback)
    task.spawn(function()
        local ok, res = pcall(function()
            return request({ Url = SUPABASE_URL.."/rest/v1/playlists?PlaylistId=eq."..tostring(playlistId).."&OwnerId=eq."..tostring(player.UserId),
                Method = "DELETE", Headers = sbHeaders() })
        end)
        local st = ok and res and tonumber(res.StatusCode) or 0
        callback(st == 200 or st == 204, "Sucesso")
    end)
end

local function sbDeleteMusic(musicId, callback)
    task.spawn(function()
        local ok, res = pcall(function()
            return request({ Url = SUPABASE_URL.."/rest/v1/musics?ID_Musica=eq."..tostring(musicId),
                Method = "DELETE", Headers = sbHeaders() })
        end)
        local st = ok and res and tonumber(res.StatusCode) or 0
        callback(st == 200 or st == 204 or st == 201)
    end)
end

-- ── Exportar ──────────────────────────────────────────────────
TMI.sbHeaders               = sbHeaders
TMI.sbPatch                 = sbPatch
TMI.fetchLikeCount          = fetchLikeCount
TMI.checkPlayerLiked        = checkPlayerLiked
TMI.giveLike                = giveLike
TMI.removeLike              = removeLike
TMI.fetchFollowCount        = fetchFollowCount
TMI.fetchFollowingCount     = fetchFollowingCount
TMI.checkIsFollowing        = checkIsFollowing
TMI.followUser              = followUser
TMI.unfollowUser            = unfollowUser
TMI.getHash                 = getHash
TMI.callApi                 = callApi
TMI.generateAccessLink      = generateAccessLink
TMI.validateKey             = validateKey
TMI.loadFullCache           = loadFullCache
TMI.fetchAllMusic           = fetchAllMusic
TMI.fetchPlaylists          = fetchPlaylists
TMI.createPlaylistAPI       = createPlaylistAPI
TMI.addSongToPlaylistAPI    = addSongToPlaylistAPI
TMI.removeSongFromPlaylistAPI = removeSongFromPlaylistAPI
TMI.deletePlaylistAPI       = deletePlaylistAPI
TMI.sbDeleteMusic           = sbDeleteMusic

print("[TMI] api.lua carregado ✓")
